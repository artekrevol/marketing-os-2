import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";
import { buildRoutedSystem } from "../_shared/playbook.ts";
import { logUsage } from "../_shared/usage.ts";
import { buildAnthropicUserId } from "../_shared/anthropicMeta.ts";

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { project_id, section_id, last_answer } = await req.json();
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: project } = await supabase.from("projects").select("*").eq("id", project_id).single();
    const { data: outline } = await supabase.from("outlines").select("sections, h1").eq("project_id", project_id).single();
    const section = (outline?.sections as any[]).find((s: any) => s.id === section_id);
    const { data: prior } = await supabase.from("interview_answers").select("*").eq("project_id", project_id).order("created_at");

    const interviewInstructions = `You are interviewing the writer to extract their voice and POV for the section "${section?.heading}" (job: ${section?.job}) of "${outline?.h1}". Ask ONE question at a time. Reactive, conversational. Build on prior answers. Use playbook ICP/voice context to ask sharper questions.`;
    const { system: routedSystem, included } = await buildRoutedSystem(supabase, "interview", interviewInstructions);
    console.log(`[interview-step] routed playbook sections: [${included.join(",")}]`);

    const t0 = Date.now();
    const MODEL = "claude-sonnet-4-5-20250929";
    const metadataUserId = buildAnthropicUserId({
      pod: project.pod,
      stage: "stage3",
      substage: `interview_${section_id || "unknown"}`,
      writer_id: project.writer_id,
    });
    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 800,
        metadata: { user_id: metadataUserId },
        system: routedSystem,
        messages: [
          {
            role: "user",
            content: `Prior Q&A:\n${(prior || []).map((p: any) => `Q: ${p.question}\nA: ${p.answer}`).join("\n\n")}\n\nLast answer from writer: ${last_answer || "(none yet — ask the first question)"}\n\nReact briefly (1 sentence) to the last answer, then ask the next question. Return only:\nREACTION: ...\nNEXT_QUESTION: ...`,
          },
        ],
      }),
    });
    const data = await resp.json();
    await logUsage(supabase, {
      project_id,
      stage: "interview",
      sub_stage: section_id,
      model: MODEL,
      metadata_user_id: metadataUserId,
      usage: data.usage,
      duration_ms: Date.now() - t0,
      ok: resp.ok,
    });
    const text = (data.content || []).find((b: any) => b.type === "text")?.text || "";
    const reaction = text.match(/REACTION:\s*(.+?)(?=NEXT_QUESTION:|$)/s)?.[1]?.trim() || "";
    const next_question = text.match(/NEXT_QUESTION:\s*(.+)/s)?.[1]?.trim() || "Tell me more.";

    return new Response(JSON.stringify({ reaction, next_question }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});