import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";
import { parsePlaybookSections, ALWAYS_INCLUDE } from "../_shared/playbook.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

/**
 * Re-parse the latest uploaded playbook into playbook_sections without
 * requiring a re-upload. Used to backfill sections for older versions
 * after Phase 2 routing shipped.
 */
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: latest } = await supabase
      .from("playbook")
      .select("version, content_markdown")
      .order("version", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (!latest) throw new Error("no playbook uploaded yet");
    const version = (latest as any).version as number;
    const markdown = ((latest as any).content_markdown as string) || "";

    const sections = parsePlaybookSections(markdown);
    if (sections.length === 0) {
      return new Response(
        JSON.stringify({ ok: false, version, sections_count: 0, error: "no sections detected" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Replace any existing rows for this version
    await supabase.from("playbook_sections").delete().eq("version", version);
    const rows = sections.map((s) => ({
      version,
      section_number: s.section_number,
      section_title: s.section_title,
      section_content: s.section_content,
      section_token_estimate: s.section_token_estimate,
      always_include: ALWAYS_INCLUDE.includes(s.section_number) || s.always_include,
    }));
    const { error } = await supabase.from("playbook_sections").insert(rows);
    if (error) throw error;

    return new Response(
      JSON.stringify({
        ok: true,
        version,
        sections_count: sections.length,
        sections: sections.map((s) => ({
          n: s.section_number,
          title: s.section_title,
          tokens: s.section_token_estimate,
        })),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e) {
    console.error("playbook-reparse error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});