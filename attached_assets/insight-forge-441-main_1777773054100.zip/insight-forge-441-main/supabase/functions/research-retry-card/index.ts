import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";
import { runStage, prefetchPages, STAGE_KEYS, type StageKey } from "../_shared/researchStages.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { project_id, stage } = await req.json();
    if (!project_id) throw new Error("project_id required");
    if (!stage || !STAGE_KEYS.includes(stage as StageKey)) throw new Error(`invalid stage: ${stage}`);

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const { data: project, error: projErr } = await supabase
      .from("projects")
      .select("*")
      .eq("id", project_id)
      .single();
    if (projErr || !project) throw new Error("project not found");

    const pages = await prefetchPages(supabase, project);

    const run = async () => {
      await runStage({ supabase, project, stage: stage as StageKey, pages });
    };

    // @ts-ignore
    if (typeof EdgeRuntime !== "undefined" && EdgeRuntime.waitUntil) {
      // @ts-ignore
      EdgeRuntime.waitUntil(run());
    } else {
      run();
    }

    return new Response(JSON.stringify({ ok: true, stage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("research-retry-card error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});