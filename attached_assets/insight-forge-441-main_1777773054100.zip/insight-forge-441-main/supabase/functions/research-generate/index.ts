import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";
import { runStage, prefetchPages, STAGE_KEYS, STAGE_LABELS } from "../_shared/researchStages.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { project_id } = await req.json();
    if (!project_id) throw new Error("project_id required");

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const { data: project, error: projErr } = await supabase
      .from("projects")
      .select("*")
      .eq("id", project_id)
      .single();
    if (projErr || !project) throw new Error("project not found");

    // Initialize sub_status: every stage pending. Reset all stage columns to null on rerun.
    const initialSubStatus: Record<string, any> = {};
    for (const k of STAGE_KEYS) {
      initialSubStatus[k] = { status: "pending", label: STAGE_LABELS[k], error: null };
    }

    await supabase.from("research_briefs").upsert(
      {
        project_id,
        sub_status: initialSubStatus,
        proof_points_status: "pending",
        progress_error: null,
        progress_stage: 0,
        progress_status: [],
        // clear previous outputs so the UI shows fresh skeletons
        search_intent: null,
        benchmark_teardown: null,
        competitor_teardown: null,
        synergy_map: null,
        ai_citation_landscape: null,
        atomic_question_map: null,
        entity_data_requirements: null,
        angle_inventory: null,
        conversion_signals: null,
      },
      { onConflict: "project_id" } as any,
    );

    console.log(`[research-generate] project=${project_id} starting parallel stages`);

    // Pre-fetch URL content (cached 1h) BEFORE running stages so all parallel
    // stages share the same fetched text.
    const t0 = Date.now();
    const pages = await prefetchPages(supabase, project);
    console.log(`[research-generate] prefetch done in ${Date.now() - t0}ms`);

    // Fire-and-forget background runner so we can return quickly.
    const runAll = async () => {
      try {
        const results = await Promise.allSettled(
          STAGE_KEYS.map((stage) =>
            runStage({ supabase, project, stage, pages }),
          ),
        );
        const okCount = results.filter((r) => r.status === "fulfilled" && (r.value as any).ok).length;
        console.log(`[research-generate] project=${project_id} done: ${okCount}/${STAGE_KEYS.length} ok`);

        // Update project status if at least the core stages succeeded
        await supabase
          .from("projects")
          .update({
            status: okCount === STAGE_KEYS.length ? "research_ready" : "research_partial",
          })
          .eq("id", project_id);
      } catch (e) {
        console.error(`[research-generate] background runner crashed:`, e);
        await supabase
          .from("research_briefs")
          .update({ progress_error: e instanceof Error ? e.message : String(e) })
          .eq("project_id", project_id);
      }
    };

    // EdgeRuntime.waitUntil keeps the function alive after the response is sent.
    // Fallback to plain Promise if not available.
    // @ts-ignore - Deno deploy globals
    if (typeof EdgeRuntime !== "undefined" && EdgeRuntime.waitUntil) {
      // @ts-ignore
      EdgeRuntime.waitUntil(runAll());
    } else {
      // best-effort
      runAll();
    }

    return new Response(JSON.stringify({ ok: true, started: STAGE_KEYS }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("research-generate error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});