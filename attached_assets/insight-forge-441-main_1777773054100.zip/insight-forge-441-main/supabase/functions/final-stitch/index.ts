import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY")!;
// GoWinston AI key (stored under the ORIGINALITY_API_KEY secret name as a drop-in replacement)
const GOWINSTON_API_KEY = Deno.env.get("ORIGINALITY_API_KEY");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const BANNED = ["in today's fast-paced world", "in conclusion", "leverage", "synergy", "delve", "navigate the landscape", "game-changer", "unlock the power"];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { project_id } = await req.json();
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: outline } = await supabase.from("outlines").select("*").eq("project_id", project_id).single();
    const { data: drafts } = await supabase.from("drafts").select("*").eq("project_id", project_id);
    const { data: brief } = await supabase
      .from("research_briefs")
      .select("atomic_question_map, entity_data_requirements, ai_citation_landscape")
      .eq("project_id", project_id)
      .maybeSingle();

    const sectionsOrder = (outline?.sections as any[]).map((s: any) => s.id);
    const ordered = sectionsOrder
      .map((id) => drafts?.find((d: any) => d.section_id === id))
      .filter(Boolean) as any[];

    let stitched = `# ${outline?.h1}\n\n`;
    for (const d of ordered) {
      stitched += `## ${d.section_heading}\n\n${d.content}\n\n`;
    }

    // word count
    const word_count = stitched.split(/\s+/).filter(Boolean).length;

    // banned phrase count
    const lower = stitched.toLowerCase();
    const banned_phrase_count = BANNED.reduce((n, p) => n + (lower.split(p).length - 1), 0);

    // citation completeness: drafts with citation_count > 0 / total drafts
    const withCites = ordered.filter((d) => (d.citation_count || 0) > 0).length;
    const citation_completeness = ordered.length ? Math.round((withCites / ordered.length) * 100) : 0;

    // average voice match
    const voice_match_score =
      ordered.length
        ? Math.round(ordered.reduce((s, d) => s + (Number(d.voice_match_score) || 0), 0) / ordered.length)
        : 0;

    // AI citation aggregates
    const ai_citation_readiness_score = ordered.length
      ? Math.round(
          ordered.reduce((s, d) => s + (Number(d.ai_citation_readiness_score) || 0), 0) / ordered.length,
        )
      : 0;
    const atomic_chunks_count = ordered.reduce((n, d) => n + (Number(d.atomic_chunks_count) || 0), 0);
    const atomic_questions_count = Array.isArray(brief?.atomic_question_map)
      ? (brief!.atomic_question_map as any[]).filter((q) => q.liftable_paragraph).length
      : 0;

    // Merge schema recommendations across sections (dedupe by type, keep first jsonld for that type).
    const schemaSet = new Map<string, any>();
    for (const d of ordered) {
      const recs = (d.schema_markup_recommendations as any[]) || [];
      for (const r of recs) {
        if (r?.type && r?.jsonld && !schemaSet.has(r.type)) {
          schemaSet.set(r.type, r.jsonld);
        }
      }
    }
    // Add Article/BlogPosting fallback if missing
    if (!schemaSet.has("Article") && !schemaSet.has("BlogPosting")) {
      schemaSet.set("BlogPosting", {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        headline: outline?.h1 || "",
        description: outline?.meta_description || "",
        wordCount: word_count,
      });
    }
    const schema_markup_recommendations = Array.from(schemaSet.entries()).map(([type, jsonld]) => ({ type, jsonld }));

    // GoWinston AI detection (best-effort; non-blocking).
    // Docs: https://gowinston.ai — POST https://api.gowinston.ai/v2/ai-content-detection
    // Returns a `score` 0–100 representing the likelihood the text is human-written.
    // We store that as `originality_score` (higher = more original/human).
    let originality_score: number | null = null;
    if (GOWINSTON_API_KEY) {
      try {
        const o = await fetch("https://api.gowinston.ai/v2/ai-content-detection", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${GOWINSTON_API_KEY}`,
          },
          body: JSON.stringify({
            text: stitched.slice(0, 30000),
            sentences: false,
            language: "en",
          }),
        });
        if (o.ok) {
          const j = await o.json();
          // GoWinston returns { score: <0-100 human likelihood>, ... }
          originality_score =
            typeof j?.score === "number"
              ? Math.round(j.score)
              : j?.score?.human ?? j?.human_score ?? null;
        } else {
          console.warn("gowinston non-ok", o.status, await o.text());
        }
      } catch (e) {
        console.warn("gowinston call failed", e);
      }
    }

    await supabase.from("draft_scores").upsert(
      {
        project_id,
        voice_match_score,
        originality_score,
        banned_phrase_count,
        word_count,
        citation_completeness,
        final_draft: stitched,
        ai_citation_readiness_score,
        atomic_chunks_count,
        atomic_questions_count,
        schema_markup_recommendations,
      },
      { onConflict: "project_id" } as any,
    );

    await supabase.from("projects").update({ current_stage: 4, status: "review" }).eq("id", project_id);

    return new Response(
      JSON.stringify({
        ok: true,
        word_count,
        voice_match_score,
        originality_score,
        banned_phrase_count,
        citation_completeness,
        ai_citation_readiness_score,
        atomic_chunks_count,
        atomic_questions_count,
        schema_markup_recommendations,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});