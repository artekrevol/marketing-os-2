import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";
import { parsePlaybookSections, ALWAYS_INCLUDE } from "../_shared/playbook.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

/**
 * Accepts a JSON body: { filename, mime_type, content_base64, uploaded_by? }
 * Parses MD / PDF / DOCX into plain markdown text and stores a new playbook version.
 */
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { filename, mime_type, content_base64, uploaded_by } = await req.json();
    if (!filename || !content_base64) throw new Error("filename and content_base64 are required");

    const bytes = Uint8Array.from(atob(content_base64), (c) => c.charCodeAt(0));
    const lower = (filename as string).toLowerCase();

    let markdown = "";
    if (lower.endsWith(".md") || lower.endsWith(".markdown") || lower.endsWith(".txt") || (mime_type || "").startsWith("text/")) {
      markdown = new TextDecoder().decode(bytes);
    } else if (lower.endsWith(".pdf") || mime_type === "application/pdf") {
      const { extractText, getDocumentProxy } = await import("https://esm.sh/unpdf@0.12.1");
      const doc = await getDocumentProxy(bytes);
      const { text } = await extractText(doc, { mergePages: true });
      markdown = Array.isArray(text) ? text.join("\n\n") : String(text);
    } else if (lower.endsWith(".docx") || mime_type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
      const mammoth = await import("npm:mammoth@1.8.0");
      const result = await mammoth.convertToMarkdown({ buffer: bytes });
      markdown = result.value || "";
    } else {
      throw new Error(`Unsupported file type: ${filename}`);
    }

    markdown = (markdown || "").trim();
    if (!markdown) throw new Error("Extracted playbook is empty.");

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const { data: latest } = await supabase
      .from("playbook")
      .select("version")
      .order("version", { ascending: false })
      .limit(1)
      .maybeSingle();
    const nextVersion = ((latest as any)?.version ?? 0) + 1;

    const { data, error } = await supabase
      .from("playbook")
      .insert({
        content_markdown: markdown,
        version: nextVersion,
        source_filename: filename,
        uploaded_by: uploaded_by || null,
      })
      .select()
      .single();
    if (error) throw error;

    // Parse + persist numbered sections for routing.
    const sections = parsePlaybookSections(markdown);
    if (sections.length > 0) {
      const rows = sections.map((s) => ({
        version: nextVersion,
        section_number: s.section_number,
        section_title: s.section_title,
        section_content: s.section_content,
        section_token_estimate: s.section_token_estimate,
        always_include: ALWAYS_INCLUDE.includes(s.section_number) || s.always_include,
      }));
      const { error: secErr } = await supabase.from("playbook_sections").insert(rows);
      if (secErr) console.warn("[playbook-upload] section insert error:", secErr.message);
    } else {
      console.warn("[playbook-upload] no sections detected — routing will fall back to full doc");
    }

    return new Response(JSON.stringify({ ok: true, playbook: data, sections_count: sections.length }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("playbook-upload error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});