import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";
import { buildRoutedSystemWithProject } from "../_shared/playbook.ts";
import { logUsage } from "../_shared/usage.ts";
import { buildAnthropicUserId } from "../_shared/anthropicMeta.ts";

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

/**
 * Count REAL inline citations in drafted prose. Source of truth = the rendered
 * Markdown link `[label](http(s)://url)`. Mirrors the regex used in DraftReview's
 * citations panel so the per-section count, the panel count, and the admin sum
 * never drift apart.
 */
function countInlineCitations(text: string): number {
  if (!text) return 0;
  const re = /\[([^\]]+)\]\((https?:\/\/[^\)\s]+)\)/g;
  const seen = new Set<string>();
  for (const m of text.matchAll(re)) {
    // De-dupe by URL — the same source cited twice in one section is one citation.
    seen.add(m[2]);
  }
  return seen.size;
}

/**
 * Normalize a URL for whitelist comparison: lowercase host, strip trailing
 * slash, ignore query/fragment for the host check. We compare both the
 * full URL and the host so writers can cite a deep link off a whitelisted
 * domain (e.g. statista.com/topics/123 when the brief listed statista.com).
 */
function normalizeUrl(u: string): { full: string; host: string } | null {
  try {
    const url = new URL(u.trim());
    if (!/^https?:$/.test(url.protocol)) return null;
    const host = url.host.toLowerCase().replace(/^www\./, "");
    const full = `${url.protocol}//${host}${url.pathname.replace(/\/+$/, "")}${url.search}`;
    return { full, host };
  } catch {
    return null;
  }
}

/**
 * Build the project's verified-source whitelist. A citation URL is allowed if
 * its host matches any of these hosts. We deliberately match by host (not
 * exact URL) because a writer can legitimately deep-link into a whitelisted
 * publication (e.g. a specific Statista page when only statista.com was in
 * the brief). Adding a host to the whitelist is an explicit signal from
 * Stage 1 research, proof points, or the project's own URLs.
 */
function buildCitationWhitelist(args: {
  proofs: any[] | null;
  brief: any;
  project: any;
}): { hosts: Set<string>; sources: Array<{ url: string; host: string; label: string }> } {
  const hosts = new Set<string>();
  const sources: Array<{ url: string; host: string; label: string }> = [];
  const add = (raw: string | null | undefined, label: string) => {
    if (!raw) return;
    const n = normalizeUrl(raw);
    if (!n) return;
    hosts.add(n.host);
    sources.push({ url: n.full, host: n.host, label });
  };
  for (const p of args.proofs || []) add(p?.source_url, p?.source_publication || "proof point");
  const landscape = args.brief?.ai_citation_landscape as any;
  for (const s of landscape?.top_cited_sources || []) add(s?.url, s?.publisher || "authority");
  for (const s of landscape?.suggested_authority_sources || []) add(s?.url_or_topic, s?.publisher || "authority");
  // Intentionally NOT including benchmark_url or competitor_url. Those are
  // research inputs (read for landscape analysis), not citation sources.
  // Citing a competitor inside our own article is off-brand by default; if
  // a writer needs that, it should be an explicit override, not silently
  // permitted.
  if (args.project?.company_domain) add(`https://${args.project.company_domain}`, "self");
  return { hosts, sources };
}

/**
 * Strip inline citations whose URL host isn't in the whitelist. The replacement
 * keeps the link text in place so prose still reads naturally — we just remove
 * the (fabricated) URL. This guarantees fake citations cannot be rendered or
 * counted downstream, regardless of what the model returned.
 */
function enforceCitationWhitelist(text: string, hosts: Set<string>): { text: string; stripped: number } {
  if (!text) return { text, stripped: 0 };
  let stripped = 0;
  const out = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\)\s]+)\)/g, (_m, label, url) => {
    const n = normalizeUrl(url);
    if (n && hosts.has(n.host)) return `[${label}](${url})`;
    stripped++;
    return label; // drop the URL, keep the prose
  });
  return { text: out, stripped };
}

const DRAFT_TOOL = {
  name: "submit_draft",
  input_schema: {
    type: "object",
    properties: {
      content: { type: "string", description: "The full prose for the section, with inline citations as [Source Name](url)." },
      citation_count: { type: "number" },
      atomic_chunks_count: { type: "number", description: "Number of standalone, liftable paragraphs that fully answer one atomic question and read correctly out of context." },
      schema_markup_recommendations: {
        type: "array",
        description: "JSON-LD schema this section supports, with the actual structured object.",
        items: {
          type: "object",
          properties: {
            type: { type: "string", enum: ["FAQPage", "HowTo", "Article", "BlogPosting", "LocalBusiness", "Organization", "Product", "Review"] },
            jsonld: { type: "object", description: "The JSON-LD object with @context and @type populated." },
          },
          required: ["type", "jsonld"],
        },
      },
    },
    required: ["content"],
  },
};

const REVIEW_TOOL = {
  name: "submit_review",
  input_schema: {
    type: "object",
    properties: {
      review_questions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            kind: { type: "string", enum: ["factual", "detail", "structural"] },
            question: { type: "string" },
          },
          required: ["kind", "question"],
        },
      },
      voice_flags: {
        type: "array",
        items: {
          type: "object",
          properties: {
            phrase: { type: "string" },
            reason: { type: "string" },
            alternative: { type: "string" },
          },
        },
      },
      voice_match_score: { type: "number" },
      entity_density_score: { type: "number", description: "0-100. Percentage of required_entities for this section that were actually included." },
      ai_citation_readiness_score: {
        type: "number",
        description: "0-100. Composite of entity density, citation coverage of required_citations, atomic chunk count vs atomic_questions assigned, and schema-markup readiness.",
      },
      ai_citation_flags: {
        type: "array",
        items: {
          type: "object",
          properties: {
            kind: { type: "string", enum: ["missing_entity", "missing_citation", "weak_atomic_chunk", "no_schema"] },
            detail: { type: "string" },
          },
          required: ["kind", "detail"],
        },
      },
    },
    required: ["review_questions"],
  },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { project_id, section_id, revision_instruction } = await req.json();
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const [
      { data: project },
      { data: outline },
      { data: proofs },
      { data: brief },
      { data: existing },
    ] = await Promise.all([
      supabase.from("projects").select("*").eq("id", project_id).single(),
      supabase.from("outlines").select("*").eq("project_id", project_id).single(),
      supabase.from("proof_points").select("*").eq("project_id", project_id).eq("starred", true),
      supabase
        .from("research_briefs")
        .select("synergy_map, conversion_signals, ai_citation_landscape, atomic_question_map, entity_data_requirements, updated_at")
        .eq("project_id", project_id)
        .single(),
      supabase.from("drafts").select("*").eq("project_id", project_id).eq("section_id", section_id).maybeSingle(),
    ]);

    const section = (outline?.sections as any[]).find((s: any) => s.id === section_id);
    if (!section) throw new Error("section not in outline");
    const totalSections = (outline?.sections as any[]).length;
    const sectionIndex = (outline?.sections as any[]).findIndex((s: any) => s.id === section_id) + 1;

    const atomicForSection: string[] = (section as any).atomic_questions || [];
    const requiredEntities: string[] = (section as any).required_entities || [];
    const requiredCitations: string[] = (section as any).required_citations || [];
    const sectionSchemas: string[] = (section as any).schema_markup_types || [];
    const suggestedAuthorities = (brief?.ai_citation_landscape as any)?.suggested_authority_sources || [];

    // Project-scoped citation whitelist. Built once per draft call from the
    // already-fetched proofs + brief + project URLs (no extra DB round trip).
    const whitelist = buildCitationWhitelist({ proofs, brief, project });
    const whitelistBlock = whitelist.sources.length
      ? whitelist.sources
          .slice(0, 25)
          .map((s) => `- ${s.label}: ${s.url}`)
          .join("\n")
      : "(no verified sources for this project — do not invent any citations)";

    /* ── Per-project cached context: shared across every section + every revision ── */
    const projectContext = `=== PROJECT CONTEXT (shared across all sections) ===
Content type: ${project.content_type}
Title (H1): ${outline?.h1}
Total sections: ${totalSections}
Company domain: ${project.company_domain}

Synergy angle (${project.company_domain}'s ownable POV):
${(brief?.synergy_map as any)?.ownable_angle || "n/a"}

Tone reminder: ${outline?.tone_reminder}
CTA guidance: ${outline?.cta_placement}
Conversion belief required: ${(brief?.conversion_signals as any)?.required_belief || ""}

Starred proof points (weave EVERY relevant one in with inline citation):
${JSON.stringify(proofs || [], null, 2)}

Suggested authority publishers (use when relevant):
${suggestedAuthorities.slice(0, 8).map((s: any) => `- ${s.publisher} (${s.url_or_topic || ""})`).join("\n")}

VERIFIED CITATION WHITELIST (the ONLY URLs you may cite inline):
${whitelistBlock}

CITATION RULES — non-negotiable:
- Inline citations MUST use the form [Publisher Name](https://real-url) where the URL is on the whitelist above (matching by host is OK, so deep links into a whitelisted domain are allowed).
- NEVER invent, guess, or hallucinate URLs. If a claim has no whitelisted source, write the claim WITHOUT a citation rather than inventing one.
- Do not cite Wikipedia or AI-generated content even if it appears in the whitelist.

Banned phrases (do not use): "in today's fast-paced world", "in conclusion", "leverage", "synergy", "delve", "navigate the landscape", "game-changer", "unlock the power".
=== END PROJECT CONTEXT ===`;

    // Stable cache tag — invalidates only when underlying project state changes.
    const projectCacheTag = `project:${project_id}|outline:${outline?.updated_at || ""}|brief:${(brief as any)?.updated_at || ""}|proofs:${(proofs || []).length}`;

    /* ── Per-section, uncached instructions ── */
    const stageInstructions = revision_instruction
      ? `You are revising Section ${sectionIndex} of ${totalSections} ("${section.heading}").

Writer's revision instruction (FOLLOW THIS LITERALLY — this is the user's primary intent):
"""
${revision_instruction}
"""

Current draft:
"""
${existing?.content || ""}
"""

REVISION RULES:
1. The writer's instruction above is the PRIMARY directive. Apply it fully and visibly — do not return content that looks identical to the current draft.
2. If the instruction asks for bullet points, convert relevant prose into actual markdown bullets ("- item").
3. If the instruction asks for a reference link or citation, add a real inline citation in the form [Publisher](https://real-url) using one of the suggested authority publishers above or a starred proof point. Never invent URLs.
4. If the instruction asks for examples, statistics, or specifics, pull them from the starred proof points or suggested authorities in the project context.
5. Preserve the section's heading, target word count (±20%), and any inline citations that are still relevant.
6. Return the FULL revised section content via submit_draft (not a diff).` 
      : `You are drafting Section ${sectionIndex} of ${totalSections} ("${section.heading}"). ${section.word_count}-word target. Job: ${section.job}.

=== AI CITATION REQUIREMENTS FOR THIS SECTION ===

Atomic questions this section MUST answer as standalone, liftable paragraphs (each paragraph reads correctly out of context, completely answers one question):
${atomicForSection.length ? atomicForSection.map((q, i) => `${i + 1}. ${q}`).join("\n") : "(none assigned — still aim for at least one liftable Q&A-style paragraph if topical)"}

Required named entities this section must include (clients, dollar amounts, dates, locations, named processes, named people):
${requiredEntities.length ? requiredEntities.map((e) => `- ${e}`).join("\n") : "(none specified — still aim for concrete proper nouns over generics)"}

Required authority citations this section must inline-cite as [Publisher](url):
${requiredCitations.length ? requiredCitations.map((c) => `- ${c}`).join("\n") : "(none specified)"}

Schema markup types this section supports: ${sectionSchemas.join(", ") || "(none assigned)"}

RULES:
1. Structure AT LEAST ONE paragraph as a standalone liftable answer to one of the atomic questions above. That paragraph must read correctly out of context.
2. Include EVERY required named entity by name (not generic placeholders).
3. Inline-cite every required authority source with a real URL.
4. If a schema_markup_type is FAQPage, format the relevant Q&A as a clear question heading + answer paragraph and emit the JSON-LD in schema_markup_recommendations. If HowTo, emit ordered steps + JSON-LD.

Produce real prose. Do not produce a brief. Then call submit_draft with:
- content: the full prose for this section, with inline [Publisher](url) citations
- citation_count: number of inline citations
- atomic_chunks_count: number of standalone liftable paragraphs
- schema_markup_recommendations: JSON-LD for any schema this section supports`;

    const userMessage = revision_instruction
      ? `Revise per the instruction above. Call submit_draft.`
      : `Draft this section now. Call submit_draft.`;

    const { system, included } = await buildRoutedSystemWithProject(
      supabase,
      "draft",
      projectContext,
      projectCacheTag,
      stageInstructions,
    );
    console.log(`[draft-section] routed playbook sections: [${included.join(",")}], cache tag: ${projectCacheTag}`);

    const t0 = Date.now();
    const MODEL = "claude-sonnet-4-5-20250929";
    const draftSubstage = revision_instruction
      ? `revise_section_${sectionIndex}`
      : `draft_section_${sectionIndex}`;
    const metadataUserId = buildAnthropicUserId({
      pod: project.pod,
      stage: "stage3",
      substage: draftSubstage,
      writer_id: project.writer_id,
    });
    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 4000,
        metadata: { user_id: metadataUserId },
        system,
        tools: [DRAFT_TOOL],
        tool_choice: { type: "tool", name: "submit_draft" },
        messages: [{ role: "user", content: userMessage }],
      }),
    });

    if (!resp.ok) throw new Error(`Anthropic ${resp.status}: ${await resp.text()}`);
    const data = await resp.json();
    await logUsage(supabase, {
      project_id,
      stage: "draft",
      sub_stage: section_id,
      model: MODEL,
      metadata_user_id: metadataUserId,
      usage: data.usage,
      duration_ms: Date.now() - t0,
      ok: true,
    });
    const toolUse = (data.content || []).find((b: any) => b.type === "tool_use");
    if (!toolUse) throw new Error("No draft returned");
    const out = toolUse.input;

    // Enforce the project URL whitelist server-side. Any inline citation
    // whose host is not on the whitelist is treated as hallucinated and its
    // URL is stripped (the link text remains so prose still reads). This is
    // the floor — UI render-side validation is a second layer on top.
    const enforced = enforceCitationWhitelist(out.content || "", whitelist.hosts);
    if (enforced.stripped > 0) {
      console.log(
        `[draft-section] stripped ${enforced.stripped} non-whitelisted citation(s) from section ${section_id}`,
      );
    }
    out.content = enforced.text;

    // Count REAL inline citations (Markdown [text](http(s)://...)) from the
    // post-enforcement content. After stripping, every remaining citation is
    // guaranteed to be on the whitelist, so the count is the verified count.
    const realCitationCount = countInlineCitations(out.content || "");

    /* ── Phase 3: review pass on Haiku ── runs in parallel with the DB write ── */
    const reviewPromise = runReviewPass(supabase, {
      project_id,
      section_id,
      sectionIndex,
      pod: project.pod,
      writer_id: project.writer_id,
      content: out.content,
      requiredEntities,
      requiredCitations,
      atomicForSection,
      sectionHeading: section.heading,
    }).catch((e) => {
      console.error("[draft-section] review pass failed", e);
      return null;
    });

    const review = await reviewPromise;

    await supabase.from("drafts").upsert(
      {
        project_id,
        section_id,
        section_heading: section.heading,
        content: out.content,
        review_questions: review?.review_questions || [],
        voice_flags: review?.voice_flags || [],
        voice_match_score: review?.voice_match_score ?? 75,
        citation_count: realCitationCount,
        atomic_chunks_count: out.atomic_chunks_count ?? 0,
        entity_density_score: review?.entity_density_score ?? null,
        ai_citation_readiness_score: review?.ai_citation_readiness_score ?? null,
        schema_markup_recommendations: out.schema_markup_recommendations || [],
        revision_count: existing ? (existing.revision_count || 0) + 1 : 0,
        // Preserve approval state across revisions so that revising an already-approved
        // section does NOT silently un-approve it. Without this, the column default
        // (false) wins on every upsert and `allDone` never flips → stitch button
        // never appears.
        approved: existing?.approved ?? false,
      },
      { onConflict: "project_id,section_id" } as any,
    );

    if (revision_instruction && existing?.content) {
      await supabase.from("voice_library").insert({
        project_id,
        original_ai_text: existing.content,
        edited_human_text: out.content,
        edit_type: "revision",
      });
    }

    await supabase.from("projects").update({ current_stage: 3, status: "drafting" }).eq("id", project_id);

    return new Response(JSON.stringify({ ok: true, draft: { ...out, ...(review || {}) } }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

/* ───────────────────────────────────────────────────────────────────
 * Phase 3: review pass — Haiku 4.5 critic that scores the draft and
 * generates review questions + voice flags. No playbook needed; the
 * tiny critique prompt makes this ~10x cheaper than re-asking Sonnet.
 * ─────────────────────────────────────────────────────────────────── */
async function runReviewPass(
  supabase: ReturnType<typeof createClient>,
  args: {
    project_id: string;
    section_id: string;
    sectionIndex: number;
    pod?: string | null;
    writer_id?: string | null;
    content: string;
    requiredEntities: string[];
    requiredCitations: string[];
    atomicForSection: string[];
    sectionHeading: string;
  },
) {
  const REVIEW_MODEL = "claude-haiku-4-5-20251001";
  const t0 = Date.now();
  const metadataUserId = buildAnthropicUserId({
    pod: args.pod,
    stage: "stage3",
    substage: `review_section_${args.sectionIndex}`,
    writer_id: args.writer_id,
  });

  const system = `You are a strict editorial critic. Read the draft section and score it. Return:
- review_questions: exactly 3 (one factual, one detail, one structural)
- voice_flags: phrases that sound generic or off-brand, with alternatives
- voice_match_score: 0-100
- entity_density_score: 0-100 (% of required_entities actually present)
- ai_citation_readiness_score: 0-100 composite
- ai_citation_flags: gaps in entities, citations, atomic chunks, or schema`;

  const user = `Section: "${args.sectionHeading}"

Required entities (check inclusion):
${args.requiredEntities.length ? args.requiredEntities.map((e) => `- ${e}`).join("\n") : "(none)"}

Required citations:
${args.requiredCitations.length ? args.requiredCitations.map((c) => `- ${c}`).join("\n") : "(none)"}

Atomic questions the section is supposed to answer:
${args.atomicForSection.length ? args.atomicForSection.map((q, i) => `${i + 1}. ${q}`).join("\n") : "(none)"}

=== DRAFT ===
${args.content}
=== END DRAFT ===

Call submit_review.`;

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: REVIEW_MODEL,
      max_tokens: 1500,
      metadata: { user_id: metadataUserId },
      system,
      tools: [REVIEW_TOOL],
      tool_choice: { type: "tool", name: "submit_review" },
      messages: [{ role: "user", content: user }],
    }),
  });

  if (!resp.ok) {
    await logUsage(supabase, {
      project_id: args.project_id,
      stage: "draft",
      sub_stage: `${args.section_id}:review`,
      model: REVIEW_MODEL,
      metadata_user_id: metadataUserId,
      duration_ms: Date.now() - t0,
      ok: false,
      error: `Anthropic ${resp.status}`,
    });
    throw new Error(`review pass ${resp.status}`);
  }
  const data = await resp.json();
  await logUsage(supabase, {
    project_id: args.project_id,
    stage: "draft",
    sub_stage: `${args.section_id}:review`,
    model: REVIEW_MODEL,
    metadata_user_id: metadataUserId,
    usage: data.usage,
    duration_ms: Date.now() - t0,
    ok: true,
  });
  const toolUse = (data.content || []).find((b: any) => b.type === "tool_use");
  return toolUse?.input || null;
}