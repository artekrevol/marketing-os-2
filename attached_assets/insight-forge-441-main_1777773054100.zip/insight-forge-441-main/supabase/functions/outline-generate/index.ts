import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";
import { buildRoutedSystem } from "../_shared/playbook.ts";
import { logUsage } from "../_shared/usage.ts";
import { buildAnthropicUserId } from "../_shared/anthropicMeta.ts";

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const OUTLINE_TOOL = {
  name: "submit_outline",
  input_schema: {
    type: "object",
    properties: {
      h1: { type: "string" },
      meta_description: { type: "string" },
      tone_reminder: { type: "string" },
      cta_placement: { type: "string" },
      internal_links: { type: "array", items: { type: "string" } },
      sections: {
        type: "array",
        items: {
          type: "object",
          properties: {
            id: { type: "string" },
            heading: { type: "string" },
            level: { type: "string", enum: ["H2", "H3"] },
            job: { type: "string" },
            word_count: { type: "number" },
            proof_points: { type: "array", items: { type: "string" } },
            internal_links: { type: "array", items: { type: "string" } },
            why_it_converts: { type: "string" },
            atomic_questions: {
              type: "array",
              description: "Verbatim atomic questions from the brief that this section must answer as liftable paragraphs.",
              items: { type: "string" },
            },
            required_entities: {
              type: "array",
              description: "Named entities (clients, dollar amounts, dates, locations, processes, people) this section must include.",
              items: { type: "string" },
            },
            required_citations: {
              type: "array",
              description: "Authority publishers / sources this section must cite inline.",
              items: { type: "string" },
            },
            ai_citation_likelihood: {
              type: "string",
              enum: ["high", "medium", "low"],
              description: "Estimated likelihood that this section would be cited by an AI search engine, given its structure, entity density, and citation plan.",
            },
            schema_markup_types: {
              type: "array",
              description: "JSON-LD schema types this section's content supports (e.g. FAQPage for Q&A blocks, HowTo for steps).",
              items: { type: "string" },
            },
          },
          required: ["id", "heading", "level", "job", "word_count"],
        },
      },
    },
    required: ["h1", "meta_description", "sections"],
  },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { project_id } = await req.json();
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: project } = await supabase.from("projects").select("*").eq("id", project_id).single();
    const { data: brief } = await supabase.from("research_briefs").select("*").eq("project_id", project_id).single();
    const { data: proofs } = await supabase.from("proof_points").select("*").eq("project_id", project_id).eq("starred", true);

    const outlineInstructions = `Honor the playbook for ICP language, banned phrases, and pillar alignment when shaping the outline.

You must also distribute the brief's atomic_question_map across sections — every atomic question with liftable_paragraph=true must be assigned to exactly one section as a standalone, citation-ready paragraph. Distribute the entity_data_requirements proportionally across sections so the article hits its minimums. Estimate ai_citation_likelihood for each section based on entity density, atomic-question coverage, and citation plan.`;
    const { system: routedSystem, included } = await buildRoutedSystem(supabase, "outline", outlineInstructions);
    console.log(`[outline-generate] routed playbook sections: [${included.join(",")}]`);

    const t0 = Date.now();
    const MODEL = "claude-sonnet-4-5-20250929";
    const metadataUserId = buildAnthropicUserId({
      pod: project.pod,
      stage: "stage2",
      substage: "outline",
      writer_id: project.writer_id,
    });
    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 4000,
        metadata: { user_id: metadataUserId },
        tools: [OUTLINE_TOOL],
        tool_choice: { type: "tool", name: "submit_outline" },
        system: routedSystem,
        messages: [
          {
            role: "user",
            content: `Build an outline for a ${project.content_type} on "${project.topic}" (${project.funnel_stage}, keyword: ${project.keyword}).

Approved research:
${JSON.stringify(brief, null, 2).slice(0, 8000)}

Starred proof points:
${JSON.stringify(proofs || [], null, 2).slice(0, 4000)}

Produce 6-9 sections. Each section gets:
- unique id (e.g. "s1"), heading, level (H2/H3), one-sentence job, target word count
- proof_points: ids the section should deploy
- internal_links
- why_it_converts: one line
- atomic_questions: verbatim questions from the brief's atomic_question_map this section must answer (each as a liftable paragraph)
- required_entities: which named entities (specific clients, dollar amounts, dates, locations, processes, people) this section must include — pull from synergy_map and entity_data_requirements
- required_citations: which authority publishers / URLs this section must inline-cite — pull from suggested_authority_sources and proof_points
- ai_citation_likelihood: high/medium/low
- schema_markup_types: JSON-LD types this section supports (FAQPage for Q&A blocks, HowTo for stepwise content, etc.)

Cover EVERY atomic question with liftable_paragraph=true at least once. Distribute entities and citations so the article hits the entity_data_requirements minimums. Also produce H1, meta description (<160 chars), tone reminder, and CTA placement notes.`,
          },
        ],
      }),
    });

    if (!resp.ok) throw new Error(`Anthropic ${resp.status}: ${await resp.text()}`);
    const data = await resp.json();
    await logUsage(supabase, {
      project_id,
      stage: "outline",
      model: MODEL,
      metadata_user_id: metadataUserId,
      usage: data.usage,
      duration_ms: Date.now() - t0,
      ok: true,
    });
    const toolUse = (data.content || []).find((b: any) => b.type === "tool_use");
    if (!toolUse) throw new Error("No outline returned");
    const out = toolUse.input;

    await supabase.from("outlines").upsert(
      {
        project_id,
        h1: out.h1,
        meta_description: out.meta_description,
        sections: out.sections,
        cta_placement: out.cta_placement,
        internal_links: out.internal_links || [],
        tone_reminder: out.tone_reminder,
      },
      { onConflict: "project_id" } as any,
    );

    await supabase.from("projects").update({ current_stage: 2, status: "outlining" }).eq("id", project_id);

    return new Response(JSON.stringify({ ok: true, outline: out }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});