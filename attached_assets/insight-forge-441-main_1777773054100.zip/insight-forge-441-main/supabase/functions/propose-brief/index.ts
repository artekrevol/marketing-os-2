import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";
import { buildRoutedSystem } from "../_shared/playbook.ts";
import { logUsage } from "../_shared/usage.ts";
import { buildAnthropicUserId } from "../_shared/anthropicMeta.ts";

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const PROPOSE_TOOL = {
  name: "submit_brief_proposal",
  description: "Submit the structured Step-2 brief proposal.",
  input_schema: {
    type: "object",
    properties: {
      keyword_cluster: {
        type: "array",
        items: {
          type: "object",
          properties: {
            keyword: { type: "string" },
            estimated_monthly_volume: { type: "number" },
            volume_is_estimated: { type: "boolean" },
            competition: { type: "string", enum: ["low", "medium", "high"] },
            is_primary: { type: "boolean" },
            reasoning: { type: "string" },
          },
          required: ["keyword", "competition", "is_primary"],
        },
      },
      primary_keyword_reasoning: { type: "string" },
      funnel_stage: { type: "string", enum: ["TOFU", "MOFU", "BOFU"] },
      funnel_reasoning: { type: "string" },
      icps: {
        type: "array",
        items: {
          type: "object",
          properties: {
            id: { type: "number" },
            label: { type: "string" },
            playbook_citation: { type: "string", description: "Quote or section name from the playbook that justifies this match." },
          },
          required: ["id", "label", "playbook_citation"],
        },
      },
      pod: { type: "string" },
      pod_reasoning: { type: "string" },
      benchmark_candidates: {
        type: "array",
        items: {
          type: "object",
          properties: {
            url: { type: "string" },
            publisher: { type: "string" },
            why: { type: "string" },
            rank: { type: "number" },
          },
          required: ["url", "publisher", "why", "rank"],
        },
      },
      competitor_candidates: {
        type: "array",
        items: {
          type: "object",
          properties: {
            url: { type: "string" },
            publisher: { type: "string" },
            serp_position: { type: "number" },
            why: { type: "string" },
            rank: { type: "number" },
          },
          required: ["url", "why", "rank"],
        },
      },
      content_type: { type: "string", enum: ["blog", "landing", "service", "case_study"] },
      mode: { type: "string", enum: ["composition", "interview"] },
      mode_reasoning: { type: "string" },
      ai_citation_landscape: {
        type: "object",
        description: "How this topic is currently surfaced in AI search (ChatGPT, Claude, Perplexity, Gemini, Google AI Overviews).",
        properties: {
          sample_buyer_prompts: {
            type: "array",
            description: "5 sample prompts a real ICP would type into an LLM.",
            items: { type: "string" },
          },
          top_cited_sources: {
            type: "array",
            description: "Top 5 sources currently cited or summarized for this topic across AI engines.",
            items: {
              type: "object",
              properties: {
                url: { type: "string" },
                publisher: { type: "string" },
                kind: { type: "string", enum: ["competitor", "aggregator", "authority", "owned_media", "other"] },
                why_cited: { type: "string" },
              },
              required: ["url", "publisher", "kind", "why_cited"],
            },
          },
          citation_gaps: {
            type: "array",
            description: "Authority sources missing, under-substantiated claims, where the company can insert itself.",
            items: { type: "string" },
          },
          suggested_authority_sources: {
            type: "array",
            description: "Authority publishers (Statista, Pew, Gartner, BLS, peer-reviewed, etc.) to cite to increase LLM citation probability.",
            items: {
              type: "object",
              properties: {
                publisher: { type: "string" },
                url_or_topic: { type: "string" },
                why: { type: "string" },
              },
              required: ["publisher", "why"],
            },
          },
        },
        required: ["sample_buyer_prompts", "top_cited_sources", "citation_gaps", "suggested_authority_sources"],
      },
      atomic_question_map: {
        type: "array",
        description: "8-15 specific questions a buyer at this funnel stage asks. Each must be liftable as a standalone paragraph.",
        items: {
          type: "object",
          properties: {
            question: { type: "string" },
            liftable_paragraph: { type: "boolean", description: "Should be answered in a standalone, citation-ready paragraph." },
            suggested_location: { type: "string", description: "Where in the article (e.g. 'intro', 'section 3', 'FAQ block at end')." },
            requires_citation: { type: "boolean" },
          },
          required: ["question", "liftable_paragraph", "suggested_location", "requires_citation"],
        },
      },
      entity_data_requirements: {
        type: "object",
        properties: {
          minimum_named_entities: {
            type: "object",
            properties: {
              clients: { type: "number" },
              dollar_amounts: { type: "number" },
              dates: { type: "number" },
              locations: { type: "number" },
              named_processes: { type: "number" },
              named_people: { type: "number" },
            },
          },
          required_authority_citations: { type: "number", description: "Minimum citations to authority publishers." },
          recommended_schema_types: {
            type: "array",
            description: "JSON-LD schema types this article should ship with.",
            items: { type: "string", enum: ["FAQPage", "HowTo", "Article", "BlogPosting", "LocalBusiness", "Organization", "Product", "Review"] },
          },
          originality_threshold: { type: "number", description: "Minimum proprietary data points that don't appear in the top 10 SERP." },
        },
        required: ["minimum_named_entities", "required_authority_citations", "recommended_schema_types", "originality_threshold"],
      },
    },
    required: [
      "keyword_cluster",
      "funnel_stage",
      "icps",
      "pod",
      "benchmark_candidates",
      "competitor_candidates",
      "content_type",
      "mode",
      "ai_citation_landscape",
      "atomic_question_map",
      "entity_data_requirements",
    ],
  },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { project_id } = await req.json();
    if (!project_id) throw new Error("project_id required");
    if (!ANTHROPIC_API_KEY) throw new Error("ANTHROPIC_API_KEY not configured");

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: project, error: pErr } = await supabase
      .from("projects")
      .select("*")
      .eq("id", project_id)
      .single();
    if (pErr || !project) throw new Error("project not found");

    // Server-side validation: topic length cap (mirrors client-side zod check
    // in NewProject.tsx). HTML maxLength is a UX hint and can be bypassed by
    // direct DB insert or paste-from-clipboard, so we re-check here before
    // burning Anthropic tokens on garbage input.
    const TOPIC_MAX = 200;
    const topicTrimmed = String(project.topic || "").trim();
    if (topicTrimmed.length === 0) {
      throw new Error("Project topic is empty.");
    }
    if (topicTrimmed.length > TOPIC_MAX) {
      const errMsg = `Project topic exceeds ${TOPIC_MAX} characters (got ${topicTrimmed.length}). Edit the topic and retry.`;
      await supabase
        .from("projects")
        .update({ status: "brief_failed", brief_error: errMsg } as any)
        .eq("id", project_id);
      return new Response(JSON.stringify({ error: errMsg }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const stageInstructions = `You are the intake research assistant for ${project.company_domain}'s content pipeline. Read the company playbook above fully before responding.

Topic the user wants to write about: ${project.topic}
User notes: ${project.user_notes || "(none)"}

Use web search to:
1. Identify the keyword cluster around this topic — 5-10 related keywords with estimated monthly search volume and competition level. Suggest one primary keyword (set is_primary=true) based on intent match and ranking opportunity.
2. Determine search intent and funnel stage (TOFU / MOFU / BOFU).
3. Match 1-4 ICPs from the playbook based on topic and keyword intent. Cite the exact playbook section or quote that justifies each match.
4. Recommend the best pod from the playbook based on topic alignment with pod specialties.
5. Find 3 high-quality benchmark blogs (editorial standards to emulate — Neil Patel, Backlinko, a16z, First Round Review, or specialist publishers in the topic's vertical) for this topic. Rank them 1-3.
6. Find the top 3 ranking competitor pages for the proposed primary keyword via live SERP. Include serp_position. Rank them 1-3 by current position.
7. Default content_type=blog and mode=composition unless the topic clearly suggests interview mode (thought leadership, founder POV).

Every proposal must include one-line reasoning. Cite playbook sections by name or quote, and cite web sources by URL. Never fabricate search volumes — if exact data isn't available, set volume_is_estimated=true and explain the basis in the reasoning field.

In addition to traditional SEO research, you must research the AI citation landscape for this topic. AI search engines (ChatGPT, Claude, Perplexity, Gemini, Google AI Overviews) reward different signals than Google.

Run web searches that mimic real buyer queries an ICP would type into an LLM. For a buyer researching ${project.topic}, examples include:
- "best [solution] for [their context]"
- "how much does [thing] cost"
- "${project.topic} vs [alternative]"
- "how to choose [solution]"
- "what to look for in [solution]"

For each query, identify:
- Which sources are currently cited or summarized
- Whether those sources are competitors, aggregators, or authority publishers
- Which claims are under-substantiated and could be improved with better sourcing
- Where ${project.company_domain} could insert itself with proprietary data, named clients, or original analysis

Then map the atomic questions this article must answer in liftable, citation-ready chunks. Atomic = a single paragraph that completely answers one question and reads correctly out of context. Aim for 8-15 atomic questions.

Then specify entity and data density requirements: minimum named entities (clients, dollar amounts, dates, locations, named processes, named people), required citations to authority publishers, and recommended JSON-LD schema markup types.

Authority publishers for citation purposes include: Statista, Pew Research, Gartner, Forrester, McKinsey, government data sources (BLS, Census, EU statistical offices), peer-reviewed research, industry-specific authoritative sources (HIMSS for healthcare, IDC for tech, Nielsen for media), and named company financial reports. Avoid suggesting low-authority aggregators like Wikipedia, generic blog roundups, or AI-generated content as citation sources.

Then call submit_brief_proposal with the complete structured output including ai_citation_landscape, atomic_question_map, and entity_data_requirements.`;

    const { system, version: playbookVersion, included } = await buildRoutedSystem(
      supabase,
      "propose_brief",
      stageInstructions,
    );
    console.log(`[propose-brief] routed playbook sections: [${included.join(",")}]`);

    const metadataUserId = buildAnthropicUserId({
      pod: project.pod,
      stage: "stage0",
      substage: "propose_brief",
      writer_id: project.writer_id,
    });

    const requestBody = JSON.stringify({
      model: "claude-sonnet-4-5-20250929",
      max_tokens: 8000,
      metadata: { user_id: metadataUserId },
      system,
      tools: [
        { type: "web_search_20250305", name: "web_search", max_uses: 3 },
        PROPOSE_TOOL,
      ],
      tool_choice: { type: "auto" },
      messages: [
        {
          role: "user",
          content:
            "HARD LIMIT: 3 web_search calls maximum across this entire task. Use them strategically (one for keyword/SERP, one for benchmark discovery, one for competitor discovery). After 3 searches you MUST synthesize and call submit_brief_proposal with whatever you have. Do not exceed 3 searches.",
        },
      ],
    });

    const callAnthropic = async (_attempt: number): Promise<Response> => {
      const ctrl = new AbortController();
      const timeout = setTimeout(() => ctrl.abort(), 290_000); // 290s client-side cap
      try {
        return await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
          },
          body: requestBody,
          signal: ctrl.signal,
        });
      } finally {
        clearTimeout(timeout);
      }
    };

    // Run the long Anthropic call in the background so we don't hit the
    // 150s edge function idle timeout. Client subscribes to `projects`
    // realtime updates and reacts when ai_proposed_brief lands.
    const runInBackground = async () => {
      try {
        let resp: Response | null = null;
        let lastErr: unknown = null;
        for (let attempt = 1; attempt <= 3; attempt++) {
          try {
            resp = await callAnthropic(attempt);
            if (resp.status >= 500 || resp.status === 429) {
              const txt = await resp.text();
              console.warn(`[propose-brief] attempt ${attempt} got ${resp.status}: ${txt.slice(0, 300)}`);
              lastErr = new Error(`Anthropic ${resp.status}`);
              resp = null;
            } else {
              break;
            }
          } catch (e) {
            lastErr = e;
            console.warn(`[propose-brief] attempt ${attempt} fetch error:`, e instanceof Error ? e.message : String(e));
          }
          if (attempt < 3) {
            await new Promise((r) => setTimeout(r, 1500 * attempt));
          }
        }

        if (!resp) {
          throw new Error(
            `Anthropic request failed after retries: ${lastErr instanceof Error ? lastErr.message : String(lastErr)}`,
          );
        }
        if (!resp.ok) {
          const txt = await resp.text();
          throw new Error(`Anthropic ${resp.status}: ${txt.slice(0, 500)}`);
        }

        const data = await resp.json();
        await logUsage(supabase, {
          project_id,
          stage: "propose_brief",
          model: "claude-sonnet-4-5-20250929",
          metadata_user_id: metadataUserId,
          usage: data.usage,
          ok: true,
        });
        const toolUse = (data.content || []).find(
          (b: any) => b.type === "tool_use" && b.name === "submit_brief_proposal",
        );
        if (!toolUse) {
          const text = (data.content || []).filter((b: any) => b.type === "text").map((b: any) => b.text).join("\n");
          throw new Error(`No proposal returned. Raw: ${text.slice(0, 500)}`);
        }
        const proposal = toolUse.input;

        const primary = (proposal.keyword_cluster || []).find((k: any) => k.is_primary);
        const benchmarkTop = (proposal.benchmark_candidates || []).sort((a: any, b: any) => a.rank - b.rank)[0];
        const competitorTop = (proposal.competitor_candidates || []).sort((a: any, b: any) => a.rank - b.rank)[0];

        await supabase.from("projects").update({
          ai_proposed_brief: proposal,
          keyword_cluster: proposal.keyword_cluster || [],
          keyword: primary?.keyword || project.keyword,
          funnel_stage: proposal.funnel_stage,
          icps: (proposal.icps || []).map((i: any) => i.id),
          pod: proposal.pod || project.pod,
          benchmark_url: benchmarkTop?.url || project.benchmark_url,
          competitor_url: competitorTop?.url || project.competitor_url,
          content_type: proposal.content_type || project.content_type,
          mode: proposal.mode || project.mode,
          playbook_version: playbookVersion,
          status: "brief_proposed",
        }).eq("id", project_id);
      } catch (e) {
        console.error("[propose-brief] background error:", e);
        const errMsg = e instanceof Error ? e.message : String(e);
        // Try the full update with brief_error first; fall back to status-only
        // if the column is missing in older deployments.
        const { error: updErr } = await supabase
          .from("projects")
          .update({ status: "brief_failed", brief_error: errMsg } as any)
          .eq("id", project_id);
        if (updErr) {
          console.error("[propose-brief] failed to write brief_error, falling back:", updErr.message);
          await supabase
            .from("projects")
            .update({ status: "brief_failed" })
            .eq("id", project_id);
        }
      }
    };

    // Mark project as proposing so the UI shows progress
    await supabase.from("projects").update({ status: "brief_proposing" }).eq("id", project_id);

    // @ts-ignore - EdgeRuntime is provided by Supabase edge runtime
    if (typeof EdgeRuntime !== "undefined" && EdgeRuntime.waitUntil) {
      // @ts-ignore
      EdgeRuntime.waitUntil(runInBackground());
    } else {
      // Fallback: fire and forget
      runInBackground();
    }

    return new Response(JSON.stringify({ ok: true, status: "queued" }), {
      status: 202,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("propose-brief error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});