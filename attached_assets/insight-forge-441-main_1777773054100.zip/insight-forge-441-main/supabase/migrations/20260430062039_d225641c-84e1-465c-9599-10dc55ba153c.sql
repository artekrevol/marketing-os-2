ALTER TABLE public.usage_logs
  ADD COLUMN IF NOT EXISTS metadata_user_id text;

CREATE INDEX IF NOT EXISTS usage_logs_metadata_user_id_idx
  ON public.usage_logs (metadata_user_id);
