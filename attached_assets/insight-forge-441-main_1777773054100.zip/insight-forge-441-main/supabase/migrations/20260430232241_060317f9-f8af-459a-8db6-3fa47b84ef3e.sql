ALTER TABLE public.projects REPLICA IDENTITY FULL;
ALTER TABLE public.drafts REPLICA IDENTITY FULL;
ALTER TABLE public.draft_scores REPLICA IDENTITY FULL;
ALTER TABLE public.outlines REPLICA IDENTITY FULL;
ALTER TABLE public.research_briefs REPLICA IDENTITY FULL;
ALTER TABLE public.proof_points REPLICA IDENTITY FULL;

DO $$
BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.projects; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.drafts; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.draft_scores; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.outlines; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.research_briefs; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.proof_points; EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;