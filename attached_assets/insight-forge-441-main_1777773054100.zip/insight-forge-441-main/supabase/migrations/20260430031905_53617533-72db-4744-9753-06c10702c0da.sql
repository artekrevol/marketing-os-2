
REVOKE EXECUTE ON FUNCTION public.is_tekrevol_member(uuid) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.handle_new_tekrevol_user() FROM anon, authenticated, public;
