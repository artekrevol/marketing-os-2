-- Playbook table (single global playbook; latest version wins)
CREATE TABLE public.playbook (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  content_markdown TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  source_filename TEXT,
  uploaded_by TEXT,
  uploaded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.playbook ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public_all_playbook" ON public.playbook
  FOR ALL USING (true) WITH CHECK (true);

CREATE INDEX idx_playbook_version ON public.playbook(version DESC);

-- projects: new fields
ALTER TABLE public.projects
  ADD COLUMN IF NOT EXISTS keyword_cluster JSONB DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS ai_proposed_brief JSONB,
  ADD COLUMN IF NOT EXISTS user_overrides JSONB DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS playbook_version INTEGER,
  ADD COLUMN IF NOT EXISTS user_notes TEXT,
  ADD COLUMN IF NOT EXISTS brief_confirmed_at TIMESTAMP WITH TIME ZONE;

-- research_briefs: per-stage progress
ALTER TABLE public.research_briefs
  ADD COLUMN IF NOT EXISTS progress_stage INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS progress_status JSONB DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS progress_error TEXT;

-- Allow research_briefs row to exist before content is filled in (for progress streaming)
ALTER TABLE public.research_briefs
  ADD CONSTRAINT research_briefs_project_id_unique UNIQUE (project_id);