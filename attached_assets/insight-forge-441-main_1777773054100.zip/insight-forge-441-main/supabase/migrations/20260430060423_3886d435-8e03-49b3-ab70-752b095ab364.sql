
CREATE TABLE public.usage_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid,
  stage text,
  sub_stage text,
  model text,
  input_tokens integer DEFAULT 0,
  output_tokens integer DEFAULT 0,
  cache_creation_input_tokens integer DEFAULT 0,
  cache_read_input_tokens integer DEFAULT 0,
  estimated_cost_usd numeric(10,6) DEFAULT 0,
  duration_ms integer,
  ok boolean DEFAULT true,
  error text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_usage_logs_created_at ON public.usage_logs (created_at DESC);
CREATE INDEX idx_usage_logs_project_id ON public.usage_logs (project_id);
CREATE INDEX idx_usage_logs_stage ON public.usage_logs (stage);

ALTER TABLE public.usage_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members insert usage_logs"
  ON public.usage_logs FOR INSERT TO authenticated
  WITH CHECK (public.can_access_app(auth.uid()));

CREATE POLICY "admins read usage_logs"
  ON public.usage_logs FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Admin summary function
CREATE OR REPLACE FUNCTION public.admin_usage_summary(_since timestamptz DEFAULT (now() - interval '30 days'))
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result jsonb;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::app_role) THEN
    RAISE EXCEPTION 'admin only';
  END IF;

  SELECT jsonb_build_object(
    'since', _since,
    'totals', (
      SELECT jsonb_build_object(
        'calls', count(*),
        'input_tokens', coalesce(sum(input_tokens), 0),
        'output_tokens', coalesce(sum(output_tokens), 0),
        'cache_creation_tokens', coalesce(sum(cache_creation_input_tokens), 0),
        'cache_read_tokens', coalesce(sum(cache_read_input_tokens), 0),
        'cost_usd', coalesce(sum(estimated_cost_usd), 0),
        'cache_hit_rate', CASE
          WHEN coalesce(sum(cache_read_input_tokens + cache_creation_input_tokens), 0) = 0 THEN 0
          ELSE round(
            sum(cache_read_input_tokens)::numeric
            / nullif(sum(cache_read_input_tokens + cache_creation_input_tokens), 0)
            * 100, 1)
        END,
        'errors', count(*) FILTER (WHERE ok = false)
      )
      FROM public.usage_logs WHERE created_at >= _since
    ),
    'by_stage', (
      SELECT coalesce(jsonb_agg(row_to_json(s) ORDER BY s.cost_usd DESC), '[]'::jsonb)
      FROM (
        SELECT
          coalesce(stage, 'unknown') AS stage,
          count(*) AS calls,
          sum(input_tokens) AS input_tokens,
          sum(output_tokens) AS output_tokens,
          sum(cache_read_input_tokens) AS cache_read_tokens,
          sum(cache_creation_input_tokens) AS cache_creation_tokens,
          round(sum(estimated_cost_usd)::numeric, 4) AS cost_usd
        FROM public.usage_logs
        WHERE created_at >= _since
        GROUP BY stage
      ) s
    ),
    'by_project', (
      SELECT coalesce(jsonb_agg(row_to_json(p) ORDER BY p.cost_usd DESC), '[]'::jsonb)
      FROM (
        SELECT
          ul.project_id,
          pr.topic,
          count(*) AS calls,
          round(sum(ul.estimated_cost_usd)::numeric, 4) AS cost_usd,
          sum(ul.input_tokens + ul.output_tokens) AS total_tokens
        FROM public.usage_logs ul
        LEFT JOIN public.projects pr ON pr.id = ul.project_id
        WHERE ul.created_at >= _since AND ul.project_id IS NOT NULL
        GROUP BY ul.project_id, pr.topic
        ORDER BY sum(ul.estimated_cost_usd) DESC
        LIMIT 50
      ) p
    )
  ) INTO result;

  RETURN result;
END;
$$;
