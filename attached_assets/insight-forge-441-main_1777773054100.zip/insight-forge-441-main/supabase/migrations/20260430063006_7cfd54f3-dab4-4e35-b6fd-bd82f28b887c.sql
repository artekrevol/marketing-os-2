DROP POLICY IF EXISTS "members insert usage_logs" ON public.usage_logs;
CREATE POLICY "service role inserts usage_logs"
  ON public.usage_logs FOR INSERT
  TO public
  WITH CHECK (true);