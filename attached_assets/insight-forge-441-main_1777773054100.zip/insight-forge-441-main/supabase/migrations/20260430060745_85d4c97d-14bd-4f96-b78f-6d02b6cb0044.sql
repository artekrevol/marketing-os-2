
CREATE TABLE public.playbook_sections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  version integer NOT NULL,
  section_number integer NOT NULL,
  section_title text,
  section_content text NOT NULL,
  section_token_estimate integer NOT NULL DEFAULT 0,
  always_include boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (version, section_number)
);

CREATE INDEX idx_playbook_sections_version ON public.playbook_sections (version);

ALTER TABLE public.playbook_sections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members read playbook_sections"
  ON public.playbook_sections FOR SELECT TO authenticated
  USING (public.can_access_app(auth.uid()));

CREATE POLICY "members write playbook_sections"
  ON public.playbook_sections FOR INSERT TO authenticated
  WITH CHECK (public.can_access_app(auth.uid()));

CREATE POLICY "members update playbook_sections"
  ON public.playbook_sections FOR UPDATE TO authenticated
  USING (public.can_access_app(auth.uid()))
  WITH CHECK (public.can_access_app(auth.uid()));

CREATE POLICY "members delete playbook_sections"
  ON public.playbook_sections FOR DELETE TO authenticated
  USING (public.can_access_app(auth.uid()));
