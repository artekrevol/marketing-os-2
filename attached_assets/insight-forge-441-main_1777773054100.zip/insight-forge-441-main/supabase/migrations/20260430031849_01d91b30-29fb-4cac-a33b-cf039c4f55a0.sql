
-- 1. Add created_by to projects
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS created_by uuid;

-- 2. Helper function: is this user a tekrevol member?
CREATE OR REPLACE FUNCTION public.is_tekrevol_member(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM auth.users
    WHERE id = _user_id
      AND lower(email) LIKE '%@tekrevol.com'
  )
$$;

-- 3. Helper: claim ownership of orphan projects on first signup
CREATE OR REPLACE FUNCTION public.handle_new_tekrevol_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email IS NOT NULL AND lower(NEW.email) LIKE '%@tekrevol.com' THEN
    -- assign all unowned projects to the first tekrevol user
    UPDATE public.projects SET created_by = NEW.id WHERE created_by IS NULL;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created_tekrevol ON auth.users;
CREATE TRIGGER on_auth_user_created_tekrevol
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_tekrevol_user();

-- 4. Replace public RLS policies with tekrevol-member-only policies
-- projects
DROP POLICY IF EXISTS public_all_projects ON public.projects;
CREATE POLICY "tekrevol can view projects" ON public.projects
  FOR SELECT TO authenticated
  USING (public.is_tekrevol_member(auth.uid()));
CREATE POLICY "tekrevol can insert projects" ON public.projects
  FOR INSERT TO authenticated
  WITH CHECK (public.is_tekrevol_member(auth.uid()) AND created_by = auth.uid());
CREATE POLICY "tekrevol can update projects" ON public.projects
  FOR UPDATE TO authenticated
  USING (public.is_tekrevol_member(auth.uid()))
  WITH CHECK (public.is_tekrevol_member(auth.uid()));
CREATE POLICY "tekrevol can delete projects" ON public.projects
  FOR DELETE TO authenticated
  USING (public.is_tekrevol_member(auth.uid()));

-- generic helper for the rest: same gate, all CRUD
DO $$
DECLARE
  t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'research_briefs','outlines','drafts','draft_scores',
    'proof_points','interview_answers','voice_library','playbook'
  ]) LOOP
    EXECUTE format('DROP POLICY IF EXISTS public_all_%I ON public.%I', t, t);
    EXECUTE format($f$
      CREATE POLICY "tekrevol all %1$s" ON public.%1$I
        FOR ALL TO authenticated
        USING (public.is_tekrevol_member(auth.uid()))
        WITH CHECK (public.is_tekrevol_member(auth.uid()))
    $f$, t);
  END LOOP;
END $$;
