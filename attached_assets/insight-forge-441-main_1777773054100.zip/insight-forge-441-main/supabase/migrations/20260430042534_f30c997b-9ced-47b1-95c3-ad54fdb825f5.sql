-- 1. Role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'member');

-- 2. user_roles table
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 3. has_role security definer
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;

-- 4. Combined gate: tekrevol member OR admin
CREATE OR REPLACE FUNCTION public.can_access_app(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.is_tekrevol_member(_user_id) OR public.has_role(_user_id, 'admin')
$$;

GRANT EXECUTE ON FUNCTION public.can_access_app(uuid) TO authenticated;

-- 5. user_roles policies
CREATE POLICY "admins manage roles" ON public.user_roles
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "users view own roles" ON public.user_roles
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- 6. Replace existing tekrevol-only RLS with can_access_app on every table
-- projects
DROP POLICY IF EXISTS "tekrevol can view projects" ON public.projects;
DROP POLICY IF EXISTS "tekrevol can insert projects" ON public.projects;
DROP POLICY IF EXISTS "tekrevol can update projects" ON public.projects;
DROP POLICY IF EXISTS "tekrevol can delete projects" ON public.projects;

CREATE POLICY "members view projects" ON public.projects FOR SELECT TO authenticated
  USING (public.can_access_app(auth.uid()));
CREATE POLICY "members insert projects" ON public.projects FOR INSERT TO authenticated
  WITH CHECK (public.can_access_app(auth.uid()) AND created_by = auth.uid());
CREATE POLICY "members update projects" ON public.projects FOR UPDATE TO authenticated
  USING (public.can_access_app(auth.uid()))
  WITH CHECK (public.can_access_app(auth.uid()));
CREATE POLICY "members delete projects" ON public.projects FOR DELETE TO authenticated
  USING (public.can_access_app(auth.uid()));

-- helper to swap policy on simple ALL tables
DROP POLICY IF EXISTS "tekrevol all draft_scores" ON public.draft_scores;
CREATE POLICY "members all draft_scores" ON public.draft_scores FOR ALL TO authenticated
  USING (public.can_access_app(auth.uid())) WITH CHECK (public.can_access_app(auth.uid()));

DROP POLICY IF EXISTS "tekrevol all drafts" ON public.drafts;
CREATE POLICY "members all drafts" ON public.drafts FOR ALL TO authenticated
  USING (public.can_access_app(auth.uid())) WITH CHECK (public.can_access_app(auth.uid()));

DROP POLICY IF EXISTS "tekrevol all interview_answers" ON public.interview_answers;
CREATE POLICY "members all interview_answers" ON public.interview_answers FOR ALL TO authenticated
  USING (public.can_access_app(auth.uid())) WITH CHECK (public.can_access_app(auth.uid()));

DROP POLICY IF EXISTS "tekrevol all outlines" ON public.outlines;
CREATE POLICY "members all outlines" ON public.outlines FOR ALL TO authenticated
  USING (public.can_access_app(auth.uid())) WITH CHECK (public.can_access_app(auth.uid()));

DROP POLICY IF EXISTS "tekrevol all playbook" ON public.playbook;
CREATE POLICY "members all playbook" ON public.playbook FOR ALL TO authenticated
  USING (public.can_access_app(auth.uid())) WITH CHECK (public.can_access_app(auth.uid()));

DROP POLICY IF EXISTS "tekrevol all proof_points" ON public.proof_points;
CREATE POLICY "members all proof_points" ON public.proof_points FOR ALL TO authenticated
  USING (public.can_access_app(auth.uid())) WITH CHECK (public.can_access_app(auth.uid()));

DROP POLICY IF EXISTS "tekrevol all research_briefs" ON public.research_briefs;
CREATE POLICY "members all research_briefs" ON public.research_briefs FOR ALL TO authenticated
  USING (public.can_access_app(auth.uid())) WITH CHECK (public.can_access_app(auth.uid()));

DROP POLICY IF EXISTS "tekrevol all voice_library" ON public.voice_library;
CREATE POLICY "members all voice_library" ON public.voice_library FOR ALL TO authenticated
  USING (public.can_access_app(auth.uid())) WITH CHECK (public.can_access_app(auth.uid()));

-- 7. Admin directory view (so admin page can list users without service role)
CREATE OR REPLACE FUNCTION public.list_app_users()
RETURNS TABLE (
  user_id uuid,
  email text,
  created_at timestamptz,
  last_sign_in_at timestamptz,
  is_admin boolean,
  is_tekrevol boolean,
  project_count bigint
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    u.id,
    u.email,
    u.created_at,
    u.last_sign_in_at,
    EXISTS (SELECT 1 FROM public.user_roles r WHERE r.user_id = u.id AND r.role = 'admin') AS is_admin,
    (lower(u.email) LIKE '%@tekrevol.com') AS is_tekrevol,
    (SELECT count(*) FROM public.projects p WHERE p.created_by = u.id) AS project_count
  FROM auth.users u
  WHERE public.has_role(auth.uid(), 'admin')
  ORDER BY u.created_at DESC
$$;

REVOKE EXECUTE ON FUNCTION public.list_app_users() FROM public, anon;
GRANT EXECUTE ON FUNCTION public.list_app_users() TO authenticated;

-- 8. Auto-grant admin to a specific seed email on signup, plus keep existing tekrevol behavior
CREATE OR REPLACE FUNCTION public.handle_new_tekrevol_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email IS NOT NULL AND lower(NEW.email) LIKE '%@tekrevol.com' THEN
    UPDATE public.projects SET created_by = NEW.id WHERE created_by IS NULL;
  END IF;
  -- Seed admin: first user with this email automatically becomes admin
  IF NEW.email IS NOT NULL AND lower(NEW.email) = 'admin@contentforge.local' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin')
    ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created_tekrevol ON auth.users;
CREATE TRIGGER on_auth_user_created_tekrevol
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_tekrevol_user();