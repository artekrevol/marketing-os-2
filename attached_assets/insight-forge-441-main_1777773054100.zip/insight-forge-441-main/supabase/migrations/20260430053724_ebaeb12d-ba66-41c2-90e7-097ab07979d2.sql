
ALTER TABLE public.research_briefs
  ADD COLUMN IF NOT EXISTS sub_status jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS proof_points_status text DEFAULT 'pending';

CREATE TABLE IF NOT EXISTS public.fetched_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  title text,
  content text NOT NULL,
  fetched_at timestamptz NOT NULL DEFAULT now(),
  byte_size integer,
  UNIQUE (url)
);

CREATE INDEX IF NOT EXISTS idx_fetched_pages_url_recent
  ON public.fetched_pages (url, fetched_at DESC);

ALTER TABLE public.fetched_pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members read fetched_pages"
  ON public.fetched_pages
  FOR SELECT
  TO authenticated
  USING (public.can_access_app(auth.uid()));

CREATE POLICY "members write fetched_pages"
  ON public.fetched_pages
  FOR INSERT
  TO authenticated
  WITH CHECK (public.can_access_app(auth.uid()));

CREATE POLICY "members update fetched_pages"
  ON public.fetched_pages
  FOR UPDATE
  TO authenticated
  USING (public.can_access_app(auth.uid()))
  WITH CHECK (public.can_access_app(auth.uid()));
