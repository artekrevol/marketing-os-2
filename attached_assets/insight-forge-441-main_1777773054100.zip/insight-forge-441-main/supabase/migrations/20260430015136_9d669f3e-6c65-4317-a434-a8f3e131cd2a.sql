ALTER TABLE public.research_briefs
  ADD COLUMN IF NOT EXISTS ai_citation_landscape JSONB,
  ADD COLUMN IF NOT EXISTS atomic_question_map JSONB,
  ADD COLUMN IF NOT EXISTS entity_data_requirements JSONB;

ALTER TABLE public.drafts
  ADD COLUMN IF NOT EXISTS ai_citation_readiness_score INTEGER,
  ADD COLUMN IF NOT EXISTS atomic_chunks_count INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS entity_density_score INTEGER,
  ADD COLUMN IF NOT EXISTS schema_markup_recommendations JSONB DEFAULT '[]'::jsonb;

ALTER TABLE public.draft_scores
  ADD COLUMN IF NOT EXISTS ai_citation_readiness_score INTEGER,
  ADD COLUMN IF NOT EXISTS atomic_chunks_count INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS atomic_questions_count INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS schema_markup_recommendations JSONB DEFAULT '[]'::jsonb;