-- Activity / page-time logging
CREATE TABLE public.page_events (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  user_email text,
  path text NOT NULL,
  project_id uuid,
  entered_at timestamptz NOT NULL DEFAULT now(),
  duration_ms integer,
  user_agent text,
  referrer text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_page_events_user_entered ON public.page_events (user_id, entered_at DESC);
CREATE INDEX idx_page_events_path ON public.page_events (path);
CREATE INDEX idx_page_events_entered ON public.page_events (entered_at DESC);

ALTER TABLE public.page_events ENABLE ROW LEVEL SECURITY;

-- Any authenticated app user can insert their own events
CREATE POLICY "users insert own page_events"
  ON public.page_events
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid() AND public.can_access_app(auth.uid()));

-- Users can read their own events; admins can read all
CREATE POLICY "users read own page_events"
  ON public.page_events
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- Admins can update / delete (for cleanup) — non-admins cannot
CREATE POLICY "admins manage page_events"
  ON public.page_events
  FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Admin summary helper
CREATE OR REPLACE FUNCTION public.admin_user_activity(_since timestamptz DEFAULT (now() - interval '7 days'))
RETURNS TABLE (
  user_id uuid,
  user_email text,
  path text,
  visits bigint,
  total_seconds bigint,
  avg_seconds numeric,
  max_seconds bigint,
  last_seen timestamptz
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    pe.user_id,
    coalesce(pe.user_email, u.email) AS user_email,
    pe.path,
    count(*)::bigint AS visits,
    coalesce(sum(pe.duration_ms), 0)::bigint / 1000 AS total_seconds,
    round(coalesce(avg(pe.duration_ms), 0) / 1000.0, 1) AS avg_seconds,
    coalesce(max(pe.duration_ms), 0)::bigint / 1000 AS max_seconds,
    max(pe.entered_at) AS last_seen
  FROM public.page_events pe
  LEFT JOIN auth.users u ON u.id = pe.user_id
  WHERE pe.entered_at >= _since
    AND public.has_role(auth.uid(), 'admin')
  GROUP BY pe.user_id, coalesce(pe.user_email, u.email), pe.path
  ORDER BY max(pe.entered_at) DESC
$$;