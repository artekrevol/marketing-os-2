
-- Projects
CREATE TABLE public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  topic TEXT NOT NULL,
  url TEXT,
  content_type TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'composition',
  icps INTEGER[] DEFAULT '{}',
  funnel_stage TEXT,
  keyword TEXT,
  pod TEXT,
  writer_id TEXT,
  benchmark_url TEXT,
  competitor_url TEXT,
  company_domain TEXT DEFAULT 'tekrevol.com',
  status TEXT NOT NULL DEFAULT 'researching',
  current_stage INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.research_briefs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  search_intent JSONB,
  benchmark_teardown JSONB,
  competitor_teardown JSONB,
  synergy_map JSONB,
  angle_inventory JSONB,
  conversion_signals JSONB,
  raw_output TEXT,
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.proof_points (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  claim TEXT NOT NULL,
  source_url TEXT,
  source_publication TEXT,
  publication_date TEXT,
  verification_status TEXT DEFAULT 'unverified',
  starred BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.outlines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE UNIQUE,
  h1 TEXT,
  meta_description TEXT,
  sections JSONB DEFAULT '[]'::jsonb,
  cta_placement TEXT,
  internal_links JSONB DEFAULT '[]'::jsonb,
  tone_reminder TEXT,
  locked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.drafts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  section_id TEXT NOT NULL,
  section_heading TEXT,
  content TEXT,
  review_questions JSONB DEFAULT '[]'::jsonb,
  voice_flags JSONB DEFAULT '[]'::jsonb,
  voice_match_score NUMERIC,
  citation_count INTEGER DEFAULT 0,
  revision_count INTEGER DEFAULT 0,
  approved BOOLEAN DEFAULT false,
  last_edited_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(project_id, section_id)
);

CREATE TABLE public.interview_answers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  section_id TEXT NOT NULL,
  question TEXT NOT NULL,
  answer TEXT,
  follow_up TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.voice_library (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
  original_ai_text TEXT NOT NULL,
  edited_human_text TEXT NOT NULL,
  edit_type TEXT,
  writer_id TEXT,
  captured_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.draft_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE UNIQUE,
  voice_match_score NUMERIC,
  originality_score NUMERIC,
  banned_phrase_count INTEGER DEFAULT 0,
  word_count INTEGER DEFAULT 0,
  citation_completeness NUMERIC,
  final_draft TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS and open policies (no auth in v1)
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.research_briefs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.proof_points ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.outlines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.drafts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.interview_answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.voice_library ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.draft_scores ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY['projects','research_briefs','proof_points','outlines','drafts','interview_answers','voice_library','draft_scores'])
  LOOP
    EXECUTE format('CREATE POLICY "public_all_%s" ON public.%I FOR ALL USING (true) WITH CHECK (true)', t, t);
  END LOOP;
END $$;

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE TRIGGER trg_projects_updated BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_briefs_updated BEFORE UPDATE ON public.research_briefs FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_outlines_updated BEFORE UPDATE ON public.outlines FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_drafts_updated BEFORE UPDATE ON public.drafts FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_scores_updated BEFORE UPDATE ON public.draft_scores FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
