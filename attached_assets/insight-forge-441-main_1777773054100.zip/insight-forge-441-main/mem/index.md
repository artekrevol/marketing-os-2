# Project Memory

## Core
Stage 1 research = 7 parallel Anthropic sub-stages, each writes its own column on `research_briefs`. Frontend renders via realtime postgres_changes. Never re-monolith.
Haiku for extraction stages (search_intent, atomic_and_entities) and the Stage 3 review pass. Sonnet for analysis + drafting.
Dark theme is NOT used — keep notebook/serif aesthetic intact.
All Anthropic system prompts use `buildRoutedSystem*` from `_shared/playbook.ts` so the playbook is cached + section-routed. Never inline the full playbook.
Every Anthropic call MUST send `metadata: { user_id: buildAnthropicUserId(...) }` and pass `metadata_user_id` to `logUsage`. Format: `pod__stage__substage__writer_id`.
All cached system blocks use `cache_control: { type: "ephemeral", ttl: "1h" }`. Default 5m TTL is too short for editorial pacing — never revert.
Verification standard: "code works in principle" ≠ "feature works in production." Smoke tests must reflect Rabia's actual usage pattern (8–15 min gaps between drafts), not artificial back-to-back calls.
`drafts.revision_count` is for AI revisions only. Inline human edits write `last_edited_by='human'` instead. Stage-3 cost telemetry depends on this distinction.

## Memories
- [Research stage 1 architecture](mem://features/research-stage-1) — Parallel fan-out, URL caching, retry-card endpoint, sub_status schema
- [Stage 3 drafting cost optimization](mem://features/draft-stage-3) — Two cached blocks, Haiku review pass, revision-delta payloads
- [Anthropic call metadata tagging](mem://features/anthropic-metadata) — Console + usage_logs tag format and helper
- [Anthropic prompt cache TTL](mem://features/cache-ttl) — 1h extended TTL on all cached system blocks
- [Inline prose editing](mem://features/inline-prose-editing) — Click-to-edit on DraftingInterface, voice_library capture, no AI call
- [Interview mode hidden in Sprint 2](mem://constraints/interview-mode-hidden) — BriefProposal Mode dropdown removed; do not re-expose interview option

