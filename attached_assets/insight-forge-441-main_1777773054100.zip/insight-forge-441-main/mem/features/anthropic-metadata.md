---
name: Anthropic call metadata tagging
description: Every Anthropic API call sends metadata.user_id = "${pod}__${stage}__${substage}__${writer_id}" via _shared/anthropicMeta.ts. Same string is mirrored into usage_logs.metadata_user_id so the Anthropic Console and our internal dashboard show identical tags.
type: feature
---
- Helper: `supabase/functions/_shared/anthropicMeta.ts` exports `buildAnthropicUserId({ pod, stage, substage, writer_id })`. Output is lowercased, `[a-z0-9_]` only, ≤256 chars (Anthropic's metadata.user_id cap). Missing components fall back to `admin` (pod), `unknown` (stage/substage), or `anon` (writer_id).
- Stage tags currently in use:
  - `stage0__propose_brief__…` — propose-brief
  - `stage1__<sub_stage>__…` — researchStages.runStage (search_intent, benchmark_teardown, competitor_teardown, synergy_map, ai_citation_landscape, atomic_and_entities, angle_and_conversion)
  - `stage2__outline__…` — outline-generate
  - `stage3__draft_section_<n>__…` / `revise_section_<n>` — draft-section (Sonnet)
  - `stage3__review_section_<n>__…` — draft-section (Haiku review pass)
  - `stage3__interview_<section_id>__…` — interview-step
- The same metadata string is persisted in `usage_logs.metadata_user_id` (text column added in 20260430-062042 migration). Index on that column for filter queries.
- When adding a new Anthropic call, ALWAYS:
  1. import `buildAnthropicUserId` from `_shared/anthropicMeta.ts`,
  2. include `metadata: { user_id: metadataUserId }` in the request body,
  3. pass `metadata_user_id: metadataUserId` to `logUsage(...)`.
