---
name: Stage 3 drafting cost optimization (Phase 3)
description: draft-section uses two cached blocks (playbook + per-project context) plus a Haiku review pass. Sonnet drafts content only; Haiku scores and produces review_questions/voice_flags.
type: feature
---
- `buildRoutedSystemWithProject` (in `_shared/playbook.ts`) emits TWO cached ephemeral system blocks: routed playbook + per-project context (synergy, conversion belief, starred proofs, suggested authorities, banned phrases). Per-section instructions are uncached.
- Project cache tag is `project:<id>|outline:<updated_at>|brief:<updated_at>|proofs:<count>` — stable across all sections + revisions of the same project, invalidates only on actual change.
- DRAFT_TOOL (Sonnet) only returns content + counts + schema_markup_recommendations. Revisions reuse the same shape and send instruction-only deltas.
- REVIEW_TOOL runs on Haiku 4.5 after the draft and returns review_questions (3), voice_flags, voice_match_score, entity_density_score, ai_citation_readiness_score, ai_citation_flags. Failure is non-fatal — draft persists with empty review fields and a console error.
- Review pass is logged to `usage_logs` with sub_stage = `<section_id>:review` for cost attribution.
