---
name: Inline prose editing in DraftingInterface
description: Click-to-edit textarea on the active section. Saves bypass draft-section, capture the diff to voice_library with edit_type='inline'.
type: feature
---
- Click anywhere in the rendered prose (or the "Edit prose" chip) to swap the read-only div for a textarea pre-filled with `activeDraft.content`. Mutually exclusive with the AI revise box (opening one closes the other).
- Save writes `content`, `last_edited_by='human'`, and a recomputed `citation_count` (regex over `[text](url)`) directly to `drafts`. We do NOT bump `revision_count` — that's reserved for AI revisions and Stage-3 cost telemetry depends on it (see mem://features/draft-stage-3).
- We do NOT recompute `voice_match_score` / `entity_density_score` on inline save — those are Haiku outputs from the review pass; faking them client-side would be worse than letting them go stale until the next AI revision.
- Diff is captured to `voice_library` with `edit_type='inline'` (mirrors the AI-revision capture in `supabase/functions/draft-section/index.ts`), so the writer's voice corrections feed future drafts.
- Keyboard: ⌘↵ saves when editor is open (precedes the existing approve / submit-revision binding). Esc cancels and discards. Switching sections (J/K/click) discards in-progress edits — same model as the revise box.
- A "Human edit" badge renders next to StatusPill when `last_edited_by='human'` AND the section is unapproved, so it's visible the section diverges from AI output.
- **Why:** Sprint 2 polish — writers were burning Sonnet calls to fix typos and word-swaps, hurting cost-per-article and adding 8–15 min latency per micro-edit.

