---
name: Research stage 1 architecture
description: How Stage 1 research runs — parallel sub-stages, URL caching, sub_status, retry endpoint
type: feature
---
**Edge functions:**
- `research-generate` initializes `sub_status` (all stages pending), pre-fetches benchmark/competitor/company URLs (cached 1h in `fetched_pages`), then fans out all 7 stages via `Promise.allSettled`. Returns immediately; runner uses `EdgeRuntime.waitUntil`.
- `research-retry-card` re-runs ONE stage by key.
- Shared logic in `supabase/functions/_shared/researchStages.ts`: `STAGE_KEYS`, `runStage`, `prefetchPages`, per-stage tool schemas, model+timeout+web_search caps.

**Stage keys:** search_intent, benchmark_teardown, competitor_teardown, synergy_map, angle_and_conversion (writes angle_inventory + conversion_signals + proof_points), ai_citation_landscape, atomic_and_entities (writes atomic_question_map + entity_data_requirements).

**Models:** Haiku 4.5 for search_intent + atomic_and_entities (extraction). Sonnet 4.5 for everything else.

**Timeouts:** Haiku 30s, Sonnet 60s. Each stage independent — failures don't abort siblings.

**Web search caps:** Max 3 per stage. Benchmark/competitor/synergy stages use pre-fetched URL content instead of web_search.

**DB schema:**
- `research_briefs.sub_status` (jsonb): `{ stage_key: { status: pending|running|done|error, error: string|null } }`
- `research_briefs.proof_points_status` (text): pending|done|error
- `fetched_pages` table: url (unique), title, content, fetched_at — 1h TTL

**Frontend (`ResearchDashboard.tsx`):**
- Subscribes to realtime on `research_briefs` + `proof_points`
- Splash screen shown only until first card data arrives
- Each card shows StageIcon (pending/running/done/error) + retry button on error
- Approve button gated on CORE_STAGES all done
