---
name: Anthropic prompt cache TTL
description: All cached system blocks use 1h extended TTL, not the 5m default. Set in _shared/playbook.ts on both buildCachedSystem and buildCachedSystemWithProject. Editorial workflow has 10–15 min gaps between drafts; default 5m TTL caused near-zero cache reads.
type: feature
---
- Both helpers in `supabase/functions/_shared/playbook.ts` emit `cache_control: { type: "ephemeral", ttl: "1h" }` on every cached block.
- 1h cache writes cost 2x base (vs 1.25x for 5m); reads stay 0.1x. Net win for editorial pacing.
- No `anthropic-beta` header needed — 1h TTL is GA on the standard messages API.
- If you add a new cached block anywhere, use `ttl: "1h"` to match. Do NOT introduce mixed TTLs without an explicit cost-modeling reason.
