---
name: Interview mode UI hidden in Sprint 2
description: The Mode dropdown in BriefProposal no longer offers "interview". Composition is the only selectable mode.
type: constraint
---
- The Mode field in `src/pages/BriefProposal.tsx` is rendered as a static read-only "Composition (data-driven)" label, not a select.
- Do NOT re-add the `<option value="interview">` choice. Interview mode is on the Q3 roadmap (6-week scope with Rabia voice-tuning sessions); shipping it earlier hurts ROI per engineering week.
- The `interview-step` edge function and `interview_answers` table remain in place — do not delete. Existing projects with `mode = 'interview'` must keep working.
- New projects default to `composition` per the `projects.mode` column default; no migration needed.
- **Why:** UX audit (Sprint 2 polish) — exposing interview mode without backing UX investment confuses writers and dilutes the composition-mode experience.
