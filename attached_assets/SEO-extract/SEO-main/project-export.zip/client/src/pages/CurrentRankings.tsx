import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Badge } from "@/components/ui/badge";
import { DataTable } from "@/components/ui/data-table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import TopBar from "@/components/dashboard/TopBar";
import SideNav from "@/components/dashboard/SideNav";
import { getQueryFn } from "@/lib/queryClient";
import { format, subDays } from 'date-fns';
import { ColumnDef } from "@tanstack/react-table";
import { ArrowUpDown, Filter, Download, Calendar as CalendarIcon } from 'lucide-react';

// Define the type for our current ranking data
interface CurrentRanking {
  keywordId: number;
  keyword: string;
  targetUrl: string | null;
  group: string | null;
  locationName: string;
  locationCode: string | null;
  position: number | string;
  positionChange: number | null;
  url: string | null;
  lastChecked: string | null;
  resultType: string;
  title: string | null;
  domain: string | null;
}

export default function CurrentRankings() {
  const [filterText, setFilterText] = useState("");
  const [locationFilter, setLocationFilter] = useState<string>("all");
  const [groupFilter, setGroupFilter] = useState<string>("all");
  const [positionFilter, setPositionFilter] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<string>("organic");
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [dateFrom, setDateFrom] = useState<Date | undefined>(subDays(new Date(), 30));
  const [dateTo, setDateTo] = useState<Date | undefined>(new Date());
  const [filterTekrevol, setFilterTekrevol] = useState(true);
  const [sortConfig, setSortConfig] = useState<{
    column: string | null;
    direction: 'asc' | 'desc';
  }>({ column: null, direction: 'asc' });

  // Custom query function to fetch rankings by result type
  const fetchRankingsByResultType = async () => {
    const response = await fetch(`/api/current-rankings?resultType=${activeTab}`);
    if (!response.ok) {
      throw new Error('Failed to fetch rankings');
    }
    return response.json();
  };

  // Fetch current rankings for selected result type
  const { data: rankings, error, isLoading } = useQuery<CurrentRanking[]>({
    queryKey: [`/api/current-rankings`, activeTab],
    queryFn: fetchRankingsByResultType,
  });

  // Extract unique locations and groups for filters
  const locations: string[] = rankings && Array.isArray(rankings)
    ? Array.from(new Set(rankings.map((r) => r.locationName)))
    : [];

  const groups: string[] = rankings && Array.isArray(rankings)
    ? Array.from(new Set(rankings.filter((r) => r.group).map((r) => r.group as string)))
    : [];

  // Function to sort rankings
  const sortedRankings = (data: CurrentRanking[]) => {
    if (sortConfig.column === null) return data;
    
    return [...data].sort((a, b) => {
      // Handle different column types
      if (sortConfig.column === 'position') {
        const posA = typeof a.position === 'string' ? 999 : a.position as number;
        const posB = typeof b.position === 'string' ? 999 : b.position as number;
        
        return sortConfig.direction === 'asc' 
          ? posA - posB 
          : posB - posA;
      }
      
      if (sortConfig.column === 'lastChecked') {
        const dateA = a.lastChecked ? new Date(a.lastChecked).getTime() : 0;
        const dateB = b.lastChecked ? new Date(b.lastChecked).getTime() : 0;
        
        return sortConfig.direction === 'asc' 
          ? dateA - dateB 
          : dateB - dateA;
      }
      
      // Default string comparison for other columns
      const valueA = a[sortConfig.column as keyof CurrentRanking] || '';
      const valueB = b[sortConfig.column as keyof CurrentRanking] || '';
      
      if (typeof valueA === 'string' && typeof valueB === 'string') {
        return sortConfig.direction === 'asc' 
          ? valueA.localeCompare(valueB)
          : valueB.localeCompare(valueA);
      }
      
      return 0;
    });
  };

  // Toggle sort on a column
  const handleSort = (column: string) => {
    setSortConfig(prevConfig => ({
      column,
      direction: prevConfig.column === column && prevConfig.direction === 'asc' ? 'desc' : 'asc',
    }));
  };

  // Export the current filtered results
  const exportResults = () => {
    if (!filteredRankings.length) return;
    
    const csvContent = [
      // CSV Header
      ['Keyword', 'Location', 'Group', 'Position', 'Target URL', 'Ranking URL', 'Domain', 'Title', 'Last Checked'].join(','),
      // CSV Rows
      ...filteredRankings.map(r => {
        const position = typeof r.position === 'string' ? 'Not ranked' : r.position;
        const date = r.lastChecked ? format(new Date(r.lastChecked), 'yyyy-MM-dd HH:mm') : '';
        
        return [
          `"${r.keyword}"`,
          `"${r.locationName}"`,
          `"${r.group || ''}"`,
          position,
          `"${r.targetUrl || ''}"`,
          `"${r.url || ''}"`,
          `"${r.domain || ''}"`,
          `"${r.title?.replace(/"/g, '""') || ''}"`,
          date
        ].join(',');
      })
    ].join('\n');
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `tekrevol-rankings-${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filter the rankings based on user input
  const filteredRankings = rankings && Array.isArray(rankings)
    ? sortedRankings(rankings.filter((ranking) => {
        // Apply text filter to keyword
        const textMatch = filterText === "" || 
          ranking.keyword.toLowerCase().includes(filterText.toLowerCase());
        
        // Apply location filter
        const locationMatch = locationFilter === "all" || 
          ranking.locationName === locationFilter;
        
        // Apply group filter
        const groupMatch = groupFilter === "all" || 
          ranking.group === groupFilter;
        
        // Apply position filter
        let positionMatch = true;
        if (positionFilter !== "all") {
          const position = typeof ranking.position === 'string' ? 999 : Number(ranking.position);
          
          switch (positionFilter) {
            case "top10":
              positionMatch = position <= 10;
              break;
            case "top30":
              positionMatch = position <= 30;
              break;
            case "top100":
              positionMatch = position <= 100;
              break;
            case "notRanked":
              positionMatch = position === 999 || position === 0;
              break;
          }
        }
        
        // Apply date filter
        let dateMatch = true;
        if (dateFrom || dateTo) {
          const rankingDate = ranking.lastChecked ? new Date(ranking.lastChecked) : null;
          
          if (rankingDate) {
            if (dateFrom && dateTo) {
              dateMatch = rankingDate >= dateFrom && rankingDate <= dateTo;
            } else if (dateFrom) {
              dateMatch = rankingDate >= dateFrom;
            } else if (dateTo) {
              dateMatch = rankingDate <= dateTo;
            }
          }
        }
        
        // Tekrevol domain filter
        let domainMatch = true;
        if (filterTekrevol) {
          // Only include rankings for Tekrevol domain or when "Not Ranked"
          const domain = ranking.domain?.toLowerCase() || '';
          domainMatch = domain.includes('tekrevol') || 
                       (typeof ranking.position === 'string' || 
                        ranking.position === 999 || 
                        ranking.position === 0);
        }
        
        return textMatch && locationMatch && groupMatch && positionMatch && dateMatch && domainMatch;
      }))
    : [];

  // Format position display
  const formatPosition = (position: number | string) => {
    if (position === 999 || position === 0 || position === "Not ranked") {
      return <Badge variant="outline" className="text-gray-500">Not Ranked</Badge>;
    }
    
    const pos = Number(position);
    if (pos <= 10) return <Badge className="bg-green-500">#{pos}</Badge>;
    if (pos <= 20) return <Badge className="bg-yellow-500">#{pos}</Badge>;
    return <Badge className="bg-red-500">#{pos}</Badge>;
  };
  
  // Format position change
  const formatPositionChange = (change: number | null) => {
    if (change === null || change === 0) {
      return <span className="text-muted-foreground">-</span>;
    }
    if (change > 0) {
      return <span className="text-green-500 flex items-center">↑ {change}</span>;
    }
    return <span className="text-red-500 flex items-center">↓ {Math.abs(change)}</span>;
  };

  // Define columns for the data table
  const columns: ColumnDef<CurrentRanking>[] = [
    {
      accessorKey: "keyword",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => handleSort("keyword")}
          className="p-0 hover:bg-transparent"
        >
          <span>Keyword</span>
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <span className="font-medium">{row.original.keyword}</span>
    },
    {
      accessorKey: "targetUrl",
      header: "Target URL",
      cell: ({ row }) => (
        <span className="text-muted-foreground truncate max-w-[200px]">
          {row.original.targetUrl || "-"}
        </span>
      )
    },
    {
      accessorKey: "locationName",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => handleSort("locationName")}
          className="p-0 hover:bg-transparent"
        >
          <span>Location</span>
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <span>{row.original.locationName}</span>
    },
    {
      accessorKey: "group",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => handleSort("group")}
          className="p-0 hover:bg-transparent"
        >
          <span>Group</span>
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <span>{row.original.group || "-"}</span>
    },
    {
      id: "position",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => handleSort("position")}
          className="p-0 hover:bg-transparent"
        >
          <span>Position</span>
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => (
        <span className="text-center">
          {formatPosition(row.original.position)}
        </span>
      )
    },
    {
      id: "positionChange",
      header: "Change",
      cell: ({ row }) => (
        <span className="text-center">
          {formatPositionChange(row.original.positionChange)}
        </span>
      )
    },
    {
      id: "title",
      header: "Page Title",
      cell: ({ row }) => (
        <span className="truncate max-w-[200px] inline-block">
          {row.original.title || "-"}
        </span>
      )
    },
    {
      id: "domain",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => handleSort("domain")}
          className="p-0 hover:bg-transparent"
        >
          <span>Domain</span>
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => (
        <span className="truncate max-w-[150px] inline-block">
          {row.original.domain || "-"}
        </span>
      )
    },
    {
      id: "url",
      header: "Ranking URL",
      cell: ({ row }) => (
        row.original.url 
          ? <a href={`https://${row.original.url}`} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline truncate max-w-[200px] inline-block">
              {row.original.url}
            </a>
          : <span>-</span>
      )
    },
    {
      id: "lastChecked",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => handleSort("lastChecked")}
          className="p-0 hover:bg-transparent"
        >
          <span>Last Checked</span>
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        try {
          return (
            <span>
              {row.original.lastChecked ? 
                format(new Date(row.original.lastChecked), 'MMM d, yyyy HH:mm') : 
                "Never"}
            </span>
          );
        } catch (error) {
          console.error("Date formatting error:", error);
          return <span>Invalid date</span>;
        }
      }
    }
  ];

  return (
    <div className="flex h-screen">
      <SideNav />
      
      <div className="flex-1 flex flex-col">
        <TopBar title="Current Rankings" onMobileMenuToggle={() => {}} />
        
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="max-w-7xl mx-auto">
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Rankings Filter</CardTitle>
                <CardDescription>
                  Filter the current keyword rankings by various criteria
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-4">
                  {/* Basic filters */}
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-1">
                      <Input
                        placeholder="Filter by keyword..."
                        value={filterText}
                        onChange={(e) => setFilterText(e.target.value)}
                        className="w-full"
                      />
                    </div>
                    
                    <div className="w-full md:w-48">
                      <Select
                        value={locationFilter}
                        onValueChange={(value) => setLocationFilter(value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Location" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Locations</SelectItem>
                          {locations.map((location) => (
                            <SelectItem key={location} value={location}>
                              {location}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="w-full md:w-48">
                      <Select
                        value={groupFilter}
                        onValueChange={(value) => setGroupFilter(value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Group" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Groups</SelectItem>
                          {groups.map((group) => (
                            <SelectItem key={group} value={group}>
                              {group}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="w-full md:w-48">
                      <Select
                        value={positionFilter}
                        onValueChange={(value) => setPositionFilter(value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Position" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Positions</SelectItem>
                          <SelectItem value="top10">Top 10</SelectItem>
                          <SelectItem value="top30">Top 30</SelectItem>
                          <SelectItem value="top100">Top 100</SelectItem>
                          <SelectItem value="notRanked">Not Ranked</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Advanced filters toggle and buttons */}
                  <div className="flex flex-col md:flex-row justify-between items-center gap-2">
                    <div className="flex items-center gap-4">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                      >
                        <Filter className="h-4 w-4 mr-2" />
                        {showAdvancedFilters ? "Hide Advanced Filters" : "Show Advanced Filters"}
                      </Button>

                      <div className="flex items-center gap-2">
                        <Checkbox 
                          id="filterTekrevol" 
                          checked={filterTekrevol}
                          onCheckedChange={(checked) => setFilterTekrevol(checked as boolean)} 
                        />
                        <Label htmlFor="filterTekrevol">Show only Tekrevol domains</Label>
                      </div>
                    </div>

                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={exportResults}
                      disabled={filteredRankings.length === 0}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export to CSV
                    </Button>
                  </div>

                  {/* Advanced filters */}
                  {showAdvancedFilters && (
                    <div className="mt-4 p-4 border rounded-md bg-muted/20">
                      <h3 className="text-sm font-medium mb-4">Advanced Filtering Options</h3>
                      <div className="flex flex-col md:flex-row gap-6">
                        <div className="flex flex-col gap-2">
                          <Label htmlFor="dateFrom" className="text-xs">From Date</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                id="dateFrom"
                                variant="outline"
                                size="sm"
                                className="w-[240px] justify-start text-left font-normal"
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {dateFrom ? format(dateFrom, "PPP") : "Select date"}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={dateFrom}
                                onSelect={setDateFrom}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        </div>

                        <div className="flex flex-col gap-2">
                          <Label htmlFor="dateTo" className="text-xs">To Date</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                id="dateTo"
                                variant="outline"
                                size="sm"
                                className="w-[240px] justify-start text-left font-normal"
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {dateTo ? format(dateTo, "PPP") : "Select date"}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={dateTo}
                                onSelect={setDateTo}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        </div>

                        <div className="flex flex-col gap-2 md:mt-6">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setDateFrom(undefined);
                              setDateTo(undefined);
                              setPositionFilter("all");
                              setFilterTekrevol(true);
                            }}
                          >
                            Reset Filters
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Current Rankings</CardTitle>
                <CardDescription>
                  Current rankings for all your tracked keywords by result type
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs
                  defaultValue="organic"
                  value={activeTab}
                  onValueChange={setActiveTab}
                  className="w-full"
                >
                  <TabsList className="grid grid-cols-3 mb-8">
                    <TabsTrigger value="organic">Main Organic Results</TabsTrigger>
                    <TabsTrigger value="other_organic">Other Organic Results</TabsTrigger>
                    <TabsTrigger value="local_pack">Local Pack (GMB)</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="organic" className="mt-0">
                    <div className="text-sm text-muted-foreground mb-4">
                      Main organic search results from the standard listings section
                    </div>
                    {isLoading ? (
                      <div className="flex justify-center items-center h-64">
                        <div className="text-lg">Loading rankings data...</div>
                      </div>
                    ) : error ? (
                      <div className="text-red-500">Error loading rankings data</div>
                    ) : (
                      <DataTable 
                        data={filteredRankings}
                        columns={columns}
                        searchColumn="keyword"
                        searchPlaceholder="Search keywords..."
                      />
                    )}
                  </TabsContent>
                  
                  <TabsContent value="other_organic" className="mt-0">
                    <div className="text-sm text-muted-foreground mb-4">
                      Additional organic search results that appear in other sections like featured snippets
                    </div>
                    {isLoading ? (
                      <div className="flex justify-center items-center h-64">
                        <div className="text-lg">Loading rankings data...</div>
                      </div>
                    ) : error ? (
                      <div className="text-red-500">Error loading rankings data</div>
                    ) : (
                      <DataTable 
                        data={filteredRankings}
                        columns={columns}
                        searchColumn="keyword"
                        searchPlaceholder="Search keywords..."
                      />
                    )}
                  </TabsContent>
                  
                  <TabsContent value="local_pack" className="mt-0">
                    <div className="text-sm text-muted-foreground mb-4">
                      Local pack results from Google My Business listings (map results)
                    </div>
                    {isLoading ? (
                      <div className="flex justify-center items-center h-64">
                        <div className="text-lg">Loading rankings data...</div>
                      </div>
                    ) : error ? (
                      <div className="text-red-500">Error loading rankings data</div>
                    ) : (
                      <DataTable 
                        data={filteredRankings}
                        columns={columns}
                        searchColumn="keyword"
                        searchPlaceholder="Search keywords..."
                      />
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}