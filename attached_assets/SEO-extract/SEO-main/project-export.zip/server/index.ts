import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

/**
 * Setup express middleware for request logging
 */
function setupRequestLogging(app: express.Express) {
  app.use((req, res, next) => {
    const start = Date.now();
    const path = req.path;
    let capturedJsonResponse: Record<string, any> | undefined = undefined;

    const originalResJson = res.json;
    res.json = function (bodyJson, ...args) {
      capturedJsonResponse = bodyJson;
      return originalResJson.apply(res, [bodyJson, ...args]);
    };

    res.on("finish", () => {
      const duration = Date.now() - start;
      if (path.startsWith("/api")) {
        let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
        if (capturedJsonResponse) {
          logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
        }

        if (logLine.length > 80) {
          logLine = logLine.slice(0, 79) + "…";
        }

        log(logLine);
      }
    });

    next();
  });
}

/**
 * Create and configure the express app
 * This is used both in development and production
 */
export function createApp() {
  const app = express();
  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));
  
  // Setup request logging
  setupRequestLogging(app);
  
  return app;
}

/**
 * Setup error handling middleware
 */
export function setupErrorHandling(app: express.Express) {
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    console.error(`API Error: ${status} - ${message}`);
    if (err.stack) {
      console.error(err.stack);
    }

    res.status(status).json({ message });
    
    // In production, don't throw the error further to avoid crashing the server
    if (process.env.NODE_ENV !== 'production') {
      throw err;
    }
  });
}

// In development mode, start the server directly
if (process.env.NODE_ENV !== 'production') {
  (async () => {
    const app = createApp();
    const server = await registerRoutes(app);
    
    setupErrorHandling(app);

    // Setup Vite in development mode
    await setupVite(app, server);

    // Start the server
    const port = 5000;
    server.listen({
      port,
      host: "0.0.0.0",
      reusePort: true,
    }, () => {
      log(`serving on port ${port}`);
    });
  })();
}

// Re-export registerRoutes for production use
export { registerRoutes };
