import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from '@shared/schema';

// Initialize database connection
const connectionString = process.env.DATABASE_URL!;
// For development, use SSL where required; Replit provides a PostgreSQL database with SSL
const sql = postgres(connectionString, { ssl: 'require' });
export const db = drizzle(sql, { schema });

// Export types for convenience
export type DbType = typeof db;