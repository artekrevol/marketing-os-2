import axios from 'axios';
import { Keyword, Location } from '@shared/schema';
import { getDataForSEOLocationCode } from './locationCodesUtil';

/**
 * Interface for DataForSEO API response
 */
interface DataForSEOSearchItem {
  type: string;
  rank_group: number;
  rank_absolute: number;
  domain: string;
  title: string;
  url: string;
}

interface DataForSEOTask {
  id: string;
  status_code: number;
  status_message: string;
  result: Array<{
    items: DataForSEOSearchItem[];
  }>;
}

interface DataForSEOSearchResponse {
  status_code: number;
  status_message: string;
  tasks: DataForSEOTask[];
}

export interface SearchResult {
  position: number;
  url: string | null;
  resultType: 'organic' | 'other_organic' | 'local_pack';
  title?: string;
  domain?: string;
}

export interface CompetitorResult {
  domain: string;
  url: string;
  title: string;
  position: number;
}

/**
 * Search using DataForSEO API for the keyword and check ranking of target domains
 * Returns an array of search results, including the target domain position, competitors, and other results by type
 */
export const searchWithDataForSEO = async (
  keyword: Keyword,
  targetDomain: string,
  location?: Location
): Promise<{
  results: SearchResult[];
  competitors: CompetitorResult[];
}> => {
  try {
    // Try to get credentials from both possible environment variable names
    const apiLogin = process.env.DATAFORSEO_API_LOGIN || process.env.DATAFORSEO_LOGIN;
    const apiPassword = process.env.DATAFORSEO_API_PASSWORD || process.env.DATAFORSEO_PASSWORD;

    if (!apiLogin || !apiPassword) {
      throw new Error('DataForSEO API credentials not found');
    }

    // Basic auth for DataForSEO
    const auth = Buffer.from(`${apiLogin}:${apiPassword}`).toString('base64');

    // Get the DataForSEO location code
    let locationCode = "2840"; // Default to United States
    
    // If the location has a specific DataForSEO location code stored in the database, use it
    if (location && location.dataForSEOLocationCode) {
      console.log(`Using database-defined location code for ${location.name}: ${location.dataForSEOLocationCode}`);
      locationCode = location.dataForSEOLocationCode;
    }
    // Otherwise fall back to the utility function
    else if (location) {
      const dataForSEOCode = getDataForSEOLocationCode(location);
      if (dataForSEOCode) {
        locationCode = dataForSEOCode;
      } else {
        console.log(`No specific location code found for ${location.name}, using default code ${locationCode}`);
      }
    }

    // Prepare the API payload with the location code following DataForSEO API specifications
    // Based on https://docs.dataforseo.com/v3/serp/google/organic/live/advanced/
    const payload = {
      "language_code": "en",
      "location_code": parseInt(locationCode),
      "keyword": keyword.keyword, // Do not encode, DataForSEO handles this
      "calculate_rectangles": false,
      "device": "desktop",
      "os": "windows",
      "depth": 100
    };

    console.log(`Searching for "${keyword.keyword}" using location code ${locationCode} (${location?.name || 'Default'}) via DataForSEO`);

    console.log(`Sending request to DataForSEO API for keyword "${keyword.keyword}"`);
    
    let data: DataForSEOSearchResponse;
    try {
      const response = await axios.post(
        'https://api.dataforseo.com/v3/serp/google/organic/live/advanced',
        [payload],
        {
          headers: {
            'Authorization': `Basic ${auth}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000 // 30 second timeout
        }
      );
      
      console.log(`Received response from DataForSEO API for keyword "${keyword.keyword}"`);
      data = response.data as DataForSEOSearchResponse;
    } catch (error) {
      if (axios.isAxiosError(error)) {
        console.error(`DataForSEO API request failed for keyword "${keyword.keyword}": 
          Status: ${error.response?.status || 'unknown'}, 
          Message: ${error.message}, 
          Response: ${JSON.stringify(error.response?.data || {}).substring(0, 200)}...`);
      } else {
        console.error(`Unknown error making DataForSEO API request for keyword "${keyword.keyword}": ${error}`);
      }
      throw new Error(`DataForSEO API request failed: ${error instanceof Error ? error.message : String(error)}`);
    }

    // Check API response
    if (data.status_code !== 20000) {
      console.error(`DataForSEO API error code: ${data.status_code}, message: ${data.status_message}`);
      throw new Error(`DataForSEO API error: ${data.status_message}`);
    }

    // Make sure we have at least one task
    const task = data.tasks[0];
    if (!task) {
      throw new Error('No tasks returned from DataForSEO API');
    }
    
    // Check task status
    if (task.status_code !== 20000) {
      console.error(`DataForSEO task error code: ${task.status_code}, message: ${task.status_message}`);
      throw new Error(`Task error: ${task.status_message}`);
    }

    if (!task.result?.[0]?.items?.length) {
      console.log(`No search results found for "${keyword.keyword}"`);
      const emptyResult: SearchResult = { position: -1, url: null, resultType: 'organic' };
      return { 
        results: [emptyResult],
        competitors: []
      };
    }

    console.log(`Found ${task.result[0].items.length} results for "${keyword.keyword}"`);
    
    // Process all results and categorize them
    const allResults: SearchResult[] = [];
    let mainOrganicResult: SearchResult | null = null;
    let foundTarget = false;
    
    // Categorize all items from the raw results for proper position calculation
    const allItems = task.result[0].items;
    
    // Identify ads - these typically have special URLs
    const adItems = allItems.filter(item => 
      item.url?.includes('/aclk?') ||  // Google ad click URLs
      item.url?.includes('googleadservices.com') ||  // Google Ads services domain
      item.url?.startsWith('https://www.google.com/ads/') // Direct Google ad links
    );
    
    // Identify all local pack results, both explicitly labeled and those with maps URLs
    const localPackItems = allItems.filter(item => 
      item.type === 'local_pack' ||
      // Also include organic items that are actually maps results
      (item.type === 'organic' && 
        (item.url?.includes('google.com/maps') || 
         item.url?.includes('maps.google.com') ||
         (item.title?.includes('Maps') && item.domain?.includes('google.com'))))
    );
    
    // Get true organic items by filtering out ads and local pack results
    const organicItems = allItems.filter(item => {
      // Must be organic type
      if (item.type !== 'organic') return false;
      
      // Exclude ads
      if (item.url?.includes('/aclk?') ||
          item.url?.includes('googleadservices.com') ||
          item.url?.startsWith('https://www.google.com/ads/')) {
        return false;
      }
      
      // Exclude maps/local results that are miscategorized as organic
      if (item.url?.includes('google.com/maps') || 
          item.url?.includes('maps.google.com') ||
          (item.title?.includes('Maps') && item.domain?.includes('google.com'))) {
        return false;
      }
      
      return true;
    });
    
    // Log all types found for debugging purposes
    const uniqueTypes = Array.from(new Set(allItems.map(item => item.type)));
    console.log(`Found result types: ${uniqueTypes.join(', ')}`);
    
    console.log(`Found ${organicItems.length} true organic results out of ${allItems.length} total results`);
    console.log(`Found ${localPackItems.length} local pack results`);
    console.log(`Excluded ${adItems.length} ad results from organic rankings`);
    
    // IMPORTANT: Create a more precise organic position calculation
    // We need to maintain sequential rank numbers without gaps between positions
    
    // Sort all items by their original rank order
    const sortedItems = [...allItems].sort((a, b) => a.rank_absolute - b.rank_absolute);
    
    // Create a mapping from original absolute position to true organic position
    // This corrects for the presence of ads and local pack entries
    const organicPositions: Record<number, number> = {};
    let trueOrganicPosition = 1;
    
    // Go through the sorted items and assign true organic positions only to organic results
    for (const item of sortedItems) {
      // Calculate true organic position
      if (organicItems.some(organic => organic.rank_absolute === item.rank_absolute)) {
        organicPositions[item.rank_absolute] = trueOrganicPosition++;
      }
    }
    
    console.log('Organic position mapping:', organicPositions);
    
    // Log item types by rank to help debug where local packs appear
    console.log('Item types by rank:');
    sortedItems
      .slice(0, 10) // Just show the first 10 for brevity
      .forEach(item => {
        console.log(`Rank ${item.rank_absolute}: ${item.type} - ${item.domain} - True Position: ${organicPositions[item.rank_absolute] || 'N/A'}`);
      });
    
    // Sort organicItems by position first to ensure we find the highest ranked match
    const sortedOrganicItems = [...organicItems].sort((a, b) => {
      const posA = organicPositions[a.rank_absolute] || 9999;
      const posB = organicPositions[b.rank_absolute] || 9999;
      return posA - posB; // Sort by position, lowest number (highest rank) first
    });
    
    // Process organic results in order of rank (highest first)
    for (const item of sortedOrganicItems) {
      try {
        const itemDomain = item.domain.toLowerCase();
        const itemUrl = item.url;
        const itemTitle = item.title;
        
        // Get the target URL from the keyword, or use the default target domain
        const specificUrl = keyword.targetUrl?.toLowerCase();
        
        let isMatch = false;

        // First check: exact domain match
        if (itemDomain.includes(targetDomain.toLowerCase())) {
          isMatch = true;
        }
        // Second check: specific URL match if provided
        else if (specificUrl) {
          // Remove protocol and www for comparison
          const cleanSpecificUrl = specificUrl
            .replace(/^https?:\/\//i, '')
            .replace(/^www\./i, '');
          const cleanItemUrl = itemUrl
            .replace(/^https?:\/\//i, '')
            .replace(/^www\./i, '');

          if (cleanItemUrl.startsWith(cleanSpecificUrl) || 
              cleanSpecificUrl.startsWith(cleanItemUrl)) {
            isMatch = true;
          }
        }

        // Only save matching results (Tekrevol domains)
        if (isMatch) {
          // Get the true organic position (excluding ads)
          const truePosition = organicPositions[item.rank_absolute];
          
          console.log(`Found target at position ${truePosition} (true organic position) / ${item.rank_absolute} (API position): ${itemUrl}`);
          
          // Create the result object
          const result: SearchResult = {
            position: truePosition, // Use true organic position instead of absolute
            url: itemUrl,
            resultType: 'organic', // Always mark as main organic for dashboard
            title: itemTitle,
            domain: itemDomain
          };
          
          // First matching result becomes the main one
          if (!foundTarget) {
            mainOrganicResult = result;
            foundTarget = true;
            // Only add the highest ranking match to results
            allResults.push(result);
            break; // Exit the loop after finding the highest ranked match
          }
        }
        
      } catch (error) {
        console.error('Error processing organic search result:', error);
        continue;
      }
    }
    
    // Process local pack results
    for (const item of localPackItems) {
      try {
        // Local pack items have different structure, extract what we can
        const itemDomain = item.domain || '';
        const itemUrl = item.url || '';
        const itemTitle = item.title || '';
        
        // Only include Tekrevol domains
        if (itemDomain.toLowerCase().includes(targetDomain.toLowerCase()) || 
            itemUrl.toLowerCase().includes(targetDomain.toLowerCase())) {
          
          // Create the result object
          const result: SearchResult = {
            position: item.rank_absolute,
            url: itemUrl,
            resultType: 'local_pack',
            title: itemTitle,
            domain: itemDomain
          };
          
          // Add this result to our collection
          allResults.push(result);
          console.log(`Found target at position ${item.rank_absolute} (local_pack): ${itemUrl}`);
        }
        
      } catch (error) {
        console.error('Error processing local pack result:', error);
        continue;
      }
    }
    
    // If we didn't find the target domain in the results
    if (!foundTarget) {
      console.log(`Target domain "${targetDomain}" not found in top ${task.result[0].items.length} results`);
      // Add a placeholder for the main organic result
      const emptyResult: SearchResult = {
        position: -1,
        url: null,
        resultType: 'organic'
      };
      allResults.unshift(emptyResult);
    }
    
    // Collect top competitor data from organic results
    // Skip any results that match the target domain
    const competitors: CompetitorResult[] = [];
    
    // Use the sorted organicItems to gather competitor data
    for (const item of sortedOrganicItems.slice(0, 10)) { // Get top 10 results
      try {
        const itemDomain = item.domain.toLowerCase();
        
        // Skip items matching the target domain
        if (itemDomain.includes(targetDomain.toLowerCase())) {
          continue;
        }
        
        // Get the true organic position
        const truePosition = organicPositions[item.rank_absolute] || item.rank_absolute;
        
        // Create the competitor object
        const competitor: CompetitorResult = {
          domain: itemDomain,
          url: item.url,
          title: item.title,
          position: truePosition
        };
        
        competitors.push(competitor);
        
        // Limit to top 10 competitors
        if (competitors.length >= 10) {
          break;
        }
      } catch (error) {
        console.error('Error processing competitor data:', error);
        continue;
      }
    }
    
    console.log(`Found ${competitors.length} competitor results for "${keyword.keyword}"`);
    
    return {
      results: allResults,
      competitors
    };

  } catch (error) {
    console.error('Error searching with DataForSEO:', error);
    const errorResult: SearchResult = {
      position: -1,
      url: null,
      resultType: 'organic'
    };
    return {
      results: [errorResult],
      competitors: []
    };
  }
};