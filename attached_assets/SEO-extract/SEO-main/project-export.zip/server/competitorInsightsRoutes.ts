/**
 * Routes for the competitor insights API
 * These routes handle fetching and analyzing competitor insights
 */

import { Request, Response } from "express";
import { getCompetitorInsights } from "./onPageAPI";
import { storage } from "./storage";

export function registerCompetitorInsightsRoutes(app: any) {
  /**
   * Get insights for a specific competitor
   */
  app.get("/api/competitor-insights/:competitorId", async (req: Request, res: Response) => {
    try {
      const competitorId = Number(req.params.competitorId);
      
      if (isNaN(competitorId)) {
        return res.status(400).json({ message: "Invalid competitor ID" });
      }
      
      // Try to get existing insights from the database
      const existingInsights = await storage.getCompetitorInsights(competitorId);
      
      if (existingInsights) {
        return res.json(existingInsights);
      }
      
      // If no insights exist, fetch them using the OnPage API
      const insights = await getCompetitorInsights(competitorId);
      
      if (!insights) {
        return res.status(404).json({ message: "Failed to retrieve competitor insights" });
      }
      
      // Store the insights in the database
      const storedInsights = await storage.createCompetitorInsight({
        competitorId: insights.competitorId,
        url: insights.url,
        title: insights.title,
        description: insights.description, 
        canonical: insights.canonical,
        metaKeywords: insights.metaKeywords,
        h1: insights.h1,
        h2: insights.h2,
        h3: insights.h3,
        h4: insights.h4,
        h5: insights.h5,
        h6: insights.h6,
        keywordDensity: insights.keywordDensity,
        robotsTxt: insights.robotsTxt,
        images: insights.images,
        taskId: null // We don't need to store this for now
      });
      
      res.json(storedInsights);
    } catch (error) {
      console.error("Error getting competitor insights:", error);
      res.status(500).json({ message: "Failed to get competitor insights" });
    }
  });

  /**
   * Get all competitor insights
   */
  app.get("/api/competitor-insights", async (_req: Request, res: Response) => {
    try {
      const insights = await storage.getAllCompetitorInsights();
      res.json(insights);
    } catch (error) {
      console.error("Error getting all competitor insights:", error);
      res.status(500).json({ message: "Failed to get competitor insights" });
    }
  });

  /**
   * Analyze a competitor to get insights
   */
  app.post("/api/competitor-insights/analyze", async (req: Request, res: Response) => {
    try {
      const { competitorId } = req.body;
      
      if (!competitorId) {
        return res.status(400).json({ message: "Competitor ID is required" });
      }
      
      // Fetch the competitor data
      const competitor = await storage.getCompetitor(competitorId);
      
      if (!competitor) {
        return res.status(404).json({ message: "Competitor not found" });
      }
      
      // To avoid long-running requests, we'll just start the analysis process
      // and return a status message. In a production app, we would use a queue system
      // like Redis or RabbitMQ for this.
      
      // Check if we already have insights for this competitor
      // Delete existing insights to force a refresh with improved data
      const existingInsights = await storage.getCompetitorInsights(competitorId);
      if (existingInsights) {
        console.log(`Deleting existing insights for competitor ID ${competitorId} to refresh data`);
        await storage.deleteCompetitorInsight(existingInsights.id);
      }
      
      // Start the analysis in the background
      // This is a simple version - in production we would use a proper task queue
      setTimeout(async () => {
        try {
          console.log(`Starting background analysis for competitor ID ${competitorId}`);
          const insights = await getCompetitorInsights(competitorId);
          
          if (insights) {
            // Store the insights in the database
            await storage.createCompetitorInsight({
              competitorId: insights.competitorId,
              url: insights.url,
              title: insights.title,
              description: insights.description,
              canonical: insights.canonical,
              metaKeywords: insights.metaKeywords,
              h1: insights.h1,
              h2: insights.h2,
              h3: insights.h3,
              h4: insights.h4,
              h5: insights.h5,
              h6: insights.h6,
              keywordDensity: insights.keywordDensity,
              robotsTxt: insights.robotsTxt,
              images: insights.images,
              taskId: null // We don't need to store this for now
            });
            console.log(`Successfully stored insights for competitor ID ${competitorId}`);
          } else {
            console.error(`Failed to get insights for competitor ID ${competitorId}`);
          }
        } catch (error) {
          console.error(`Background analysis error for competitor ID ${competitorId}:`, error);
        }
      }, 0);
      
      // Return immediately with status information
      res.status(202).json({
        message: "Analysis started in background",
        status: "processing",
        competitorId: competitorId
      });
    } catch (error) {
      console.error("Error processing competitor analysis request:", error);
      res.status(500).json({ message: "Failed to analyze competitor" });
    }
  });
}