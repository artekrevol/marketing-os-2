import { storage } from './storage';
import { Keyword, InsertRanking, Location, InsertKeywordBatch, InsertKeywordBatchItem, InsertCompetitor } from '@shared/schema';
import { searchWithDataForSEO } from './dataForSEO';

// Constants for API rate limiting
const API_DELAY_MS = 5000; // 5 seconds between API calls
const MAX_KEYWORDS_PER_BATCH = 70; // Maximum keywords to process in one batch (increased from 20)
const MAX_RETRIES = 2; // Maximum retries for failed API calls

/**
 * Sleep for a specified number of milliseconds
 */
const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Crawl Google search results for a set of keywords
 */
export const crawlKeywords = async (keywordIds?: number[]) => {
  try {
    // Create a new batch
    const batchData: InsertKeywordBatch = {
      status: 'running',
      startTime: new Date(),
      endTime: null
    };
    const batch = await storage.createKeywordBatch(batchData);

    console.log(`Starting batch ${batch.id}`);

    // Get keywords to process
    let keywords: Keyword[];
    if (keywordIds && keywordIds.length > 0) {
      // If specific keywords were requested
      keywords = await Promise.all(
        keywordIds.map(id => storage.getKeyword(id))
      ).then(results => results.filter((k): k is Keyword => k !== undefined));
    } else {
      // Get all keywords from storage
      keywords = await storage.getKeywords();
    }

    // Limit batch size to prevent overwhelming the API
    if (keywords.length > MAX_KEYWORDS_PER_BATCH) {
      console.log(`Limiting batch from ${keywords.length} to ${MAX_KEYWORDS_PER_BATCH} keywords to prevent rate limiting`);
      keywords = keywords.slice(0, MAX_KEYWORDS_PER_BATCH);
    }

    console.log(`Processing ${keywords.length} keywords in batch ${batch.id}`);
    let completedCount = 0;
    let failedCount = 0;

    // Process each keyword
    for (const keyword of keywords) {
      let retryCount = 0;
      let success = false;
      
      while (retryCount <= MAX_RETRIES && !success) {
        try {
          if (retryCount > 0) {
            console.log(`Retry attempt ${retryCount} for keyword: ${keyword.keyword}`);
            // Add an exponential backoff delay on retries
            await sleep(API_DELAY_MS * Math.pow(2, retryCount));
          }
          
          console.log(`\nProcessing keyword: ${keyword.keyword}`);
          
          // Create batch item
          const batchItem: InsertKeywordBatchItem = {
            batchId: batch.id,
            keywordId: keyword.id,
            status: 'running',
            startTime: new Date(),
            endTime: null,
            message: null
          };
          await storage.createKeywordBatchItem(batchItem);

          // Get location if specified
          let location: Location | undefined;
          if (keyword.locationId) {
            location = await storage.getLocation(keyword.locationId);
          }

          // Determine the target domain to track
          // If keyword has a specific target URL set, extract the domain
          // Otherwise use a default domain
          let targetDomain = 'tekrevol.com'; // Default target domain
          
          if (keyword.targetUrl) {
            try {
              // Extract domain from URL - ensure URL has protocol
              const url = new URL(keyword.targetUrl.startsWith('http') 
                ? keyword.targetUrl 
                : `https://${keyword.targetUrl}`);
              targetDomain = url.hostname.replace('www.', '');
              console.log(`Using specific target domain: ${targetDomain} from URL: ${keyword.targetUrl}`);
            } catch (e) {
              console.log(`Invalid target URL in keyword (${keyword.targetUrl}), using default domain`);
            }
          }
          
          // Search for the keyword using DataForSEO
          console.log(`Sending API request for keyword "${keyword.keyword}" to DataForSEO...`);
          const searchData = await searchWithDataForSEO(
            keyword,
            targetDomain,
            location
          );
          
          // Extract results and competitors from response
          const results = searchData.results;
          const competitors = searchData.competitors;
          console.log(`Received ${results.length} results and ${competitors.length} competitors for keyword "${keyword.keyword}"`);

          // Create ranking records for each result type
          if (results && results.length > 0) {
            const currentDate = new Date();
            
            // Process each result and save to database
            for (const result of results) {
              // Get latest ranking for this keyword and result type
              const previousRanking = await storage.getLatestRankingsByKeywordId(keyword.id, result.resultType);
              
              // Calculate position change
              const previousPosition = previousRanking?.position || -1;
              const positionChange = previousPosition > 0 ? previousPosition - result.position : 0;
              
              const ranking: InsertRanking = {
                keywordId: keyword.id,
                position: result.position,
                previousPosition: previousPosition,
                positionChange: positionChange,
                url: result.url || "", // Ensure url is never null
                date: currentDate,
                resultType: result.resultType,
                title: result.title || "",
                domain: result.domain || "",
                isScheduled: true // Mark as scheduled since it's coming from the crawler
              };

              await storage.createRanking(ranking);
            }
            
            // Process and store competitor data
            if (competitors && competitors.length > 0) {
              console.log(`Storing ${competitors.length} competitors for keyword "${keyword.keyword}"`);
              
              for (const competitor of competitors) {
                const competitorData: InsertCompetitor = {
                  keywordId: keyword.id,
                  domain: competitor.domain,
                  url: competitor.url,
                  title: competitor.title || "",
                  position: competitor.position,
                  batchId: batch.id,
                  date: currentDate
                };
                
                await storage.createCompetitor(competitorData);
              }
            }
          }

          // Update batch item status
          await storage.updateKeywordBatchItemStatus(
            batch.id,
            keyword.id,
            'completed'
          );
          
          completedCount++;
          success = true;
          console.log(`Successfully processed keyword: ${keyword.keyword}`);

        } catch (error) {
          retryCount++;
          console.error(`Error processing keyword ${keyword.keyword} (attempt ${retryCount}):`, error);
          
          if (retryCount > MAX_RETRIES) {
            // Update batch item status as failed after max retries
            await storage.updateKeywordBatchItemStatus(
              batch.id,
              keyword.id,
              'failed',
              error instanceof Error ? error.message : 'Unknown error'
            );
            failedCount++;
            console.log(`Failed to process keyword after ${MAX_RETRIES} retries: ${keyword.keyword}`);
          }
        }
      }
      
      // Add delay between keywords to respect rate limits (even after success)
      console.log(`Waiting ${API_DELAY_MS/1000} seconds before next API request (rate limiting)...`);
      await sleep(API_DELAY_MS);
    }

    // Update batch status
    await storage.updateKeywordBatchStatus(batch.id, 'completed', new Date());
    console.log(`Batch ${batch.id} completed. ${completedCount} keywords processed successfully, ${failedCount} failed.`);
    return { batchId: batch.id, completedCount, failedCount };

  } catch (error) {
    console.error('Error in crawlKeywords:', error);
    throw error;
  }
};