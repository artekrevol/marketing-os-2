import cron from 'node-cron';
import { storage } from './storage';
import { crawlKeywords } from './crawler';

let scheduledTask: cron.ScheduledTask | null = null;

/**
 * Parse cron expression from schedule
 */
export const parseCronExpression = (expression: string): string => {
  // Return the expression if it's already a valid cron expression
  if (cron.validate(expression)) {
    return expression;
  }
  
  // Handle special values
  if (expression === 'daily') {
    return '0 4 * * *'; // 4am every day
  }
  
  if (expression === 'weekly') {
    return '0 4 * * 1'; // 4am every Monday
  }
  
  if (expression === 'monthly') {
    return '0 4 1 * *'; // 4am on the 1st of every month
  }
  
  // Default to daily at 4am if invalid
  return '0 4 * * *';
};

/**
 * Calculate the next run date given a cron expression
 */
export const calculateNextRun = (cronExpression: string): Date => {
  const parsedExpression = parseCronExpression(cronExpression);
  // Create a new Date object for calculation
  const now = new Date();
  // Add one day as a simple next run calculation
  const nextDate = new Date(now);
  nextDate.setDate(now.getDate() + 1);
  nextDate.setHours(4, 0, 0, 0); // Set to 4 AM
  return nextDate;
};

/**
 * Initialize the scheduler
 */
export const initializeScheduler = async (): Promise<void> => {
  try {
    // Stop any existing task
    if (scheduledTask) {
      scheduledTask.stop();
    }
    
    // Get the active schedule
    const schedule = await storage.getActiveSchedule();
    
    if (!schedule || !schedule.isActive) {
      console.log('No active schedule found. Automatic crawling is disabled.');
      return;
    }
    
    // Parse cron expression
    const cronExpression = parseCronExpression(schedule.cronExpression);
    
    // Calculate next run time
    const nextRun = calculateNextRun(cronExpression);
    
    // Update schedule with next run time
    await storage.updateScheduleRunInfo(
      schedule.id,
      schedule.lastRun || new Date(),
      nextRun
    );
    
    // Schedule task
    scheduledTask = cron.schedule(cronExpression, async () => {
      console.log('Running scheduled crawl...');
      
      try {
        // Run the crawl
        await crawlKeywords();
        
        // Update schedule info
        const now = new Date();
        const updatedSchedule = await storage.getActiveSchedule();
        
        if (updatedSchedule) {
          const nextRun = calculateNextRun(updatedSchedule.cronExpression);
          await storage.updateScheduleRunInfo(updatedSchedule.id, now, nextRun);
        }
      } catch (error) {
        console.error('Error in scheduled crawl:', error);
      }
    });
    
    console.log(`Scheduler initialized. Next run: ${nextRun.toLocaleString()}`);
  } catch (error) {
    console.error('Error initializing scheduler:', error);
  }
};
